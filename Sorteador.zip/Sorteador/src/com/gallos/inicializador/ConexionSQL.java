/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.inicializador;

import com.gallos.utilidades.TipoConexion;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author User
 */
public class ConexionSQL {

    private static ConexionSQL conexionSQL;
    private static ConexionSQL conexionH2;
    private static Connection conSQL = null;
    private static Connection conH2 = null;

    private ConexionSQL() {
        try {
            System.out.println("Creando ....");
            Class.forName("org.hsqldb.jdbc.JDBCDriver");
        } catch (ClassNotFoundException e) {
            System.out.println("Error obteniendo la clase " + e.getMessage());
        }
    }

    public static Connection getInstance(TipoConexion tipoConexion) {
        Connection conn = null;
        try {
            if (TipoConexion.SQL.equals(tipoConexion)) {
                if (conexionSQL == null) {
                    conexionSQL = new ConexionSQL();
                    String urlConection = "jdbc:sqlserver://localhost;instance=SQLEXPRESS;databaseName=Gallera";
                    conSQL = DriverManager.getConnection(urlConection, "dev_agros_app", "3JhgLzUIgl");
                    System.out.println("Conextado a sql");
                }
                conn = conSQL;
            } else {
                if (conexionH2 == null) {
                    conexionH2 = new ConexionSQL();
                    conH2 = DriverManager.getConnection("jdbc:hsqldb:file:db/sjdb", "sa", "");
                }
                conn = conH2;
            }
        } catch (Exception ex) {
            System.out.println("Error obteniendo conexion SQL server " + ex.getMessage() + " para " + tipoConexion.name());
        }
        return conn;
    }
}
