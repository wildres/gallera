/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.inicializador;

import com.gallos.utilidades.TipoConexion;
import com.gallos.utilidades.Utilidades;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class Conexion {
    
    private static Conexion conexionSQL;
    private static Conexion conexionH2;
    private static Connection conSQL = null;
    private static Connection conH2 = null;
    
    private Conexion() {
        try {
            System.out.println("Creando ....");
            Class.forName("org.hsqldb.jdbc.JDBCDriver");
        } catch (ClassNotFoundException e) {
            System.out.println("Error obteniendo la clase " + e.getMessage());
        }
    }
    
    public static Connection getInstance(TipoConexion tipoConexion) {
        Connection conn = null;
        try {
            if (TipoConexion.SQL.equals(tipoConexion)) {
                if (conexionSQL == null) {
                    conexionSQL = new Conexion();
                    String ip = JOptionPane.showInputDialog("Ingrese la Ip de la máquina remota");
                    StringBuilder urlConection = new StringBuilder();
                    urlConection.append("jdbc:sqlserver://");
                    urlConection.append(ip);
                    urlConection.append(";instance=SQLEXPRESS;databaseName=Gallera");
                    conSQL = DriverManager.getConnection(urlConection.toString(), "dev_agros_app", "3JhgLzUIgl");
                    System.out.println("Conextado a sql");
                }
                conn = conSQL;
            } else {
                if (conexionH2 == null) {
                    conexionH2 = new Conexion();
                    conH2 = DriverManager.getConnection("jdbc:hsqldb:file:db/sjdb", "sa", "");
                }
                conn = conH2;
            }
        } catch (Exception ex) {
            Utilidades.mostrarMensaje("Error obteniendo conexion SQL server " + ex.getMessage() + " para " + tipoConexion.name(), JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
        return conn;
    }
}
