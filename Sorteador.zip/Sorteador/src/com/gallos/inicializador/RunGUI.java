package com.gallos.inicializador;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import org.hsqldb.util.DatabaseManagerSwing;
/**
 *
 * @author User
 */
public class RunGUI {

	public static void main(String[] args) {
		System.out.println("Launching manager");
		DatabaseManagerSwing.main(new String[] { 
				"--url", "jdbc:hsqldb:file:db/sjdb", "--noexit"});

	}

}