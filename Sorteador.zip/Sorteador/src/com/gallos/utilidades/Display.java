/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.utilidades;

import com.gallos.entidades.DataVisualizador;
import com.gallos.entidades.Gallo;
import com.gallos.forms.PeleasLibresView;
import com.gallos.forms.PeleasPactadas;
import com.gallos.inicializador.Inicializador;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;
import org.jnativehook.keyboard.NativeKeyEvent;
import org.jnativehook.keyboard.NativeKeyListener;

/**
 *
 * @author User
 */
public class Display extends Reloj implements NativeKeyListener {

    //variables y comtenedores
    private final boolean peleaLibre;
    private DataVisualizador dataVisualizador;
    private long start;
    private PeleasLibresView peleasLibresView;
    private PeleasPactadas peleasPactadas;
    private JLabel labelGanador = new JLabel();
    private Java2sBevelText lblTiempoAzul;
    private Java2sBevelText lblTiempoRojo;
    private Java2sBevelText lblTiempoPrincipal;
    private Java2sBevelText lblTiempoEspuela;
    private int teclaLiberada;
    private JFrame frame;
    private Java2sBevelText lblPlumajeRojo;
    private JTextArea lblCuerdaAzul;
    private JTextArea lblCuerdaRoja;
    private Java2sBevelText lblPlumajeAzul;
    private Java2sBevelText lblNumeroPelea;
    private Java2sBevelText lblValorApuesta;
    private long startPrincipal;
    private static final Logger logger = Logger.getLogger(GlobalScreen.class.getPackage().getName());
    private NativeKeyListener nativeKeyListener = null;

    public Display(DataVisualizador dataVisualizador, boolean peleaLibre, Object view) {

        this.peleaLibre = peleaLibre;
        logger.setLevel(Level.OFF);
        if (peleaLibre) {
            peleasLibresView = (PeleasLibresView) view;
        } else {
            peleasPactadas = (PeleasPactadas) view;
        }
        this.dataVisualizador = dataVisualizador;
        contruyeVentana(dataVisualizador);
        int minutos = Integer.valueOf(Inicializador.cache.get(ParametrosGeneralesEnum.TIEMPO_PELEA.getId()).getValor());
        setTimerPrincipal(new Temporizador(lblTiempoPrincipal, TipoReloj.PRINCPAL, this, minutos));
        setTimerIzquierda(new Temporizador(lblTiempoRojo, TipoReloj.IZQUIERDA, this, Tiempo.MINUTOS_DE_SENTENCIA));
        setTimerDerecha(new Temporizador(lblTiempoAzul, TipoReloj.DERECHA, this, Tiempo.MINUTOS_DE_SENTENCIA));
        setTimerEspuela(new Temporizador(lblTiempoEspuela, TipoReloj.ESPUELA, this, Tiempo.MINUTOS_CAMBIO_ESPUELA));
        try {
            GlobalScreen.registerNativeHook();
            nativeKeyListener = this;
            GlobalScreen.addNativeKeyListener(nativeKeyListener);
        } catch (NativeHookException ex) {
            Utilidades.mostrarMensaje("Error GlobalScreen " + ex.getMessage(), JOptionPane.ERROR_MESSAGE);
        }

        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                int i = JOptionPane.showConfirmDialog(null, "Seguro que quiere salir?");
                if (i == 0) {
                    GlobalScreen.removeNativeKeyListener(nativeKeyListener);
                    dispose();
                    frame.dispose();
                }
            }
        });
    }

    public void mostrarSiguientePelea(DataVisualizador dataVisualizador) {
        this.dataVisualizador = dataVisualizador;
        getTimerPrincipal().reiniciar(Integer.valueOf(Inicializador.cache.get(ParametrosGeneralesEnum.TIEMPO_PELEA.getId()).getValor()));
        getTimerPrincipal().setIsTimerRunning(false);
        getTimerDerecha().reiniciar(Tiempo.MINUTOS_DE_SENTENCIA);
        getTimerDerecha().setIsTimerRunning(false);
        getTimerIzquierda().reiniciar(Tiempo.MINUTOS_DE_SENTENCIA);
        getTimerIzquierda().setIsTimerRunning(false);
        getTimerEspuela().reiniciar(Tiempo.MINUTOS_CAMBIO_ESPUELA);
        getTimerEspuela().setIsTimerRunning(false);
        labelGanador.setVisible(false);
        lblNumeroPelea.setText("Pelea N°: " + dataVisualizador.getNumeroPelea());
        lblValorApuesta.setText("$" + dataVisualizador.getValorApuesta());
        lblCuerdaRoja.setText(Utilidades.convertiraHTML(dataVisualizador.getGalloRojo().getCuerda().getNombre()));
        lblPlumajeRojo.setText(dataVisualizador.getGalloRojo().getPlumaje().getNombre());
        lblCuerdaAzul.setText(Utilidades.convertiraHTML(dataVisualizador.getGalloAzul().getCuerda().getNombre()));
        lblPlumajeAzul.setText(dataVisualizador.getGalloAzul().getPlumaje().getNombre());
    }

    public void actualizarDisplay(DataVisualizador dataVisualizador) {
        this.dataVisualizador = dataVisualizador;
        int minutos = Integer.valueOf(Inicializador.cache.get(ParametrosGeneralesEnum.TIEMPO_PELEA.getId()).getValor());
        setTimerPrincipal(new Temporizador(lblTiempoPrincipal, TipoReloj.PRINCPAL, this, minutos));
        setTimerIzquierda(new Temporizador(lblTiempoRojo, TipoReloj.IZQUIERDA, this, Tiempo.MINUTOS_DE_SENTENCIA));
        setTimerDerecha(new Temporizador(lblTiempoAzul, TipoReloj.DERECHA, this, Tiempo.MINUTOS_DE_SENTENCIA));
        setTimerEspuela(new Temporizador(lblTiempoEspuela, TipoReloj.ESPUELA, this, Tiempo.MINUTOS_CAMBIO_ESPUELA));
        getTimerPrincipal().reiniciar();
        getTimerDerecha().reiniciar();
        getTimerIzquierda().reiniciar();
        getTimerEspuela().reiniciar();
        labelGanador.setVisible(false);
    }

    public JPanel contruyePanelIzquierdo(Gallo galloRojo) {
        JPanel panelIzquierdo = new JPanel();
        panelIzquierdo.setBorder(new EmptyBorder(0, 25, 0, 0));
        JPanel contenedor = new JPanel();
        contenedor.setLayout(new BoxLayout(contenedor, BoxLayout.Y_AXIS));
        String texto = galloRojo.getCuerda().getNombre();
        lblCuerdaRoja = new JTextArea();
        lblCuerdaRoja.setBounds(new Rectangle(25, 15, 250, 90));
        if (peleaLibre) {
            lblCuerdaRoja.setText(texto.substring(0, 1).toUpperCase() + texto.substring(1, texto.length()).toLowerCase());
        } else {
            lblCuerdaRoja.setText(texto.substring(0, 1).toUpperCase() + texto.substring(1, texto.length()).toLowerCase() + "-" + galloRojo.getFrente().getNumeroFrente());
        }
        lblCuerdaRoja.setEditable(false);
        lblCuerdaRoja.setForeground(Color.WHITE);
        lblCuerdaRoja.setBackground(Color.RED);
        lblCuerdaRoja.setFont(lblCuerdaRoja.getFont().deriveFont(70.0f));
        lblPlumajeRojo = new Java2sBevelText(galloRojo.getPlumaje().getNombre(), new Color(190, 30, 45), false);
        lblPlumajeRojo.setFont(lblPlumajeRojo.getFont().deriveFont(60.0f));
        lblTiempoRojo = new Java2sBevelText("00:00", new Color(190, 30, 45), false);
        lblTiempoRojo.setFont(lblTiempoRojo.getFont().deriveFont(80.0f));

        JPanel panelTiempo = new JPanel();
        panelTiempo.setBorder(javax.swing.BorderFactory.createLineBorder(Color.BLACK, 8));
        panelTiempo.setLayout(new BoxLayout(panelTiempo, BoxLayout.Y_AXIS));
        panelTiempo.add(lblPlumajeRojo);
        panelTiempo.add(lblTiempoRojo);
        panelTiempo.setAlignmentY(JComponent.TOP_ALIGNMENT);
        panelTiempo.setBackground(Color.WHITE);
        panelTiempo.setPreferredSize(new Dimension(300, 200));
        contenedor.setBackground(Color.RED);
        panelIzquierdo.setBackground(Color.RED);
        contenedor.add(lblCuerdaRoja);
        if (!peleaLibre) {
            Java2sBevelText lblGramos = new Java2sBevelText(Utilidades.darFormatoVisualPeso(galloRojo.getPesoGramos()).toString(), Color.WHITE, false);
            lblGramos.setFont(lblGramos.getFont().deriveFont(60.0f));
            lblGramos.setAlignmentY(JComponent.TOP_ALIGNMENT);
            contenedor.add(lblGramos);
        }
        contenedor.add(panelTiempo);
        contenedor.setAlignmentY(JComponent.TOP_ALIGNMENT);
        panelIzquierdo.setAlignmentY(JComponent.TOP_ALIGNMENT);
        panelIzquierdo.add(contenedor);
        return panelIzquierdo;
    }

    public JPanel contruyePanelDerecho(Gallo galloAzul) {
        JPanel panelDerecho = new JPanel();
        panelDerecho.setBorder(new EmptyBorder(0, 0, 0, 25));
        JPanel contenedor = new JPanel();
        contenedor.setLayout(new BoxLayout(contenedor, BoxLayout.Y_AXIS));
        String texto = galloAzul.getCuerda().getNombre();
        if (peleaLibre) {
            lblCuerdaAzul = new JTextArea(texto.substring(0, 1).toUpperCase() + texto.substring(1, texto.length()).toLowerCase());
        } else {
            lblCuerdaAzul = new JTextArea(texto.substring(0, 1).toUpperCase() + texto.substring(1, texto.length()).toLowerCase() + "-" + galloAzul.getFrente().getNumeroFrente());
        }

        lblCuerdaAzul.setFont(lblCuerdaAzul.getFont().deriveFont(70.0f));
        lblCuerdaAzul.setForeground(Color.WHITE);
        lblCuerdaAzul.setBackground(Color.BLUE);
        lblCuerdaAzul.setEditable(false);
        lblPlumajeAzul = new Java2sBevelText(galloAzul.getPlumaje().getNombre(), new Color(35, 42, 85), false);
        lblPlumajeAzul.setFont(lblPlumajeAzul.getFont().deriveFont(60.0f));

        lblTiempoAzul = new Java2sBevelText("00:00", new Color(35, 42, 85), false);
        lblTiempoAzul.setFont(lblTiempoAzul.getFont().deriveFont(80.0f));

        JPanel panelTiempo = new JPanel();
        panelTiempo.setBorder(javax.swing.BorderFactory.createLineBorder(Color.BLACK, 8));
        panelTiempo.setLayout(new BoxLayout(panelTiempo, BoxLayout.Y_AXIS));
        panelTiempo.add(lblPlumajeAzul);
        panelTiempo.add(lblTiempoAzul);
        panelTiempo.setAlignmentY(JComponent.TOP_ALIGNMENT);
        panelTiempo.setBackground(Color.WHITE);
        panelTiempo.setPreferredSize(new Dimension(300, 200));
//        panelDerecho.setBackground(new Color(165, 165, 165));
        panelDerecho.setBackground(Color.BLUE);
//        contenedor.setBackground(new Color(165, 165, 165));
        contenedor.setBackground(Color.BLUE);
        contenedor.add(lblCuerdaAzul);
        if (!peleaLibre) {
            Java2sBevelText lblGramos = new Java2sBevelText(Utilidades.darFormatoVisualPeso(galloAzul.getPesoGramos()).toString(), Color.WHITE, false);
            lblGramos.setFont(lblGramos.getFont().deriveFont(60.0f));
            lblGramos.setAlignmentY(JComponent.TOP_ALIGNMENT);
            contenedor.add(lblGramos);
        }

        contenedor.add(panelTiempo);
        contenedor.setAlignmentY(JComponent.TOP_ALIGNMENT);
        panelDerecho.add(contenedor);
        return panelDerecho;
    }

    private void construirAlertaGanador(JFrame frame) {
        labelGanador = new JLabel("");
        labelGanador.setOpaque(true);
        labelGanador.setHorizontalAlignment(SwingConstants.CENTER);
        labelGanador.setVerticalAlignment(SwingConstants.CENTER);
        //setting background with transparency value to see though the label
        labelGanador.setFont(new Font("Tahoma", Font.BOLD, 100));
        labelGanador.setForeground(Color.BLACK);
        labelGanador.setBorder(new LineBorder(Color.gray));
        labelGanador.setBackground(new Color(190, 30, 45, 200));
        labelGanador.setVisible(false);
        labelGanador.setAlignmentX(TOP_ALIGNMENT);

        frame.getLayeredPane().add(labelGanador, JLayeredPane.POPUP_LAYER);

        JButton popupCloseButton = new JButton("Close");
        frame.getLayeredPane().add(popupCloseButton, BorderLayout.SOUTH);
        labelGanador.setSize(frame.getSize().width - 200, frame.getSize().height - 400);
        labelGanador.setLocation(100, 20);
    }

    public JPanel contruyePanelCentral() {
        JPanel panelCentral = new JPanel();
        JPanel contenedor = new JPanel();
        contenedor.setBorder(new EmptyBorder(0, 0, 500, 0));
        contenedor.setLayout(new BoxLayout(contenedor, BoxLayout.Y_AXIS));
        contenedor.setBackground(Color.WHITE);
        Java2sBevelText lblVS = new Java2sBevelText("VS", Color.WHITE, false);
        lblVS.setFont(lblVS.getFont().deriveFont(60.0f));
        lblVS.setForeground(Color.BLACK);
        lblTiempoPrincipal = new Java2sBevelText("00:42", Color.BLACK, false);
        lblTiempoPrincipal.setFont(lblTiempoPrincipal.getFont().deriveFont(150.0f));
        lblTiempoEspuela = new Java2sBevelText("00:42", new Color(0, 82, 33), false);
        lblTiempoEspuela.setFont(lblTiempoEspuela.getFont().deriveFont(80.0f));
        panelCentral.setLayout(new BoxLayout(panelCentral, BoxLayout.Y_AXIS));
        panelCentral.setBackground(Color.WHITE);
        contenedor.add(lblVS);
        contenedor.add(lblTiempoPrincipal);
        contenedor.add(lblTiempoEspuela);
        panelCentral.add(contenedor);
        return panelCentral;
    }

    public JPanel contruyePanelSuperior(String nroPelea, String valorApuesta) {
        JPanel panelSuperior = new JPanel();
        panelSuperior.setLayout(new BorderLayout());
        panelSuperior.setBorder(new EmptyBorder(0, 100, 0, 100));
        Java2sBevelText lblNombreGallera = new Java2sBevelText(Inicializador.cache.get(ParametrosGeneralesEnum.NOMBRE_GALLERA.getId()).getValor(), new Color(190, 30, 45), true);
        lblNombreGallera.setFont(lblNombreGallera.getFont().deriveFont(70.0f));

        lblNumeroPelea = new Java2sBevelText("Pelea N°: " + nroPelea, new Color(0, 0, 0), false);
        lblNumeroPelea.setFont(new Font("SansSerif", Font.BOLD, 60));

        lblValorApuesta = new Java2sBevelText("$" + valorApuesta, new Color(190, 30, 45), true);
        lblValorApuesta.setFont(lblValorApuesta.getFont().deriveFont(80.0f));

        JLabel galloRojo = new JLabel();
        galloRojo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/gallos/forms/galloRojo128.png")));
        galloRojo.setBackground(new Color(165, 165, 165));

        JLabel galloAzul = new JLabel();
        galloAzul.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/gallos/forms/galloAzul128.png")));
        galloAzul.setBackground(new Color(165, 165, 165));
        panelSuperior.setBackground(Color.WHITE);
        panelSuperior.add(lblNombreGallera, BorderLayout.NORTH);
        JPanel contenedor = new JPanel();
        contenedor.setLayout(new BoxLayout(contenedor, BoxLayout.Y_AXIS));
        contenedor.add(lblNumeroPelea);
        contenedor.add(lblValorApuesta);
        contenedor.setBackground(Color.WHITE);
        panelSuperior.add(contenedor, BorderLayout.CENTER);
        panelSuperior.add(galloRojo, BorderLayout.WEST);
        panelSuperior.add(galloAzul, BorderLayout.EAST);
        return panelSuperior;
    }

    public void contruyeVentana(DataVisualizador dataVisualizador) {
        frame = new JFrame();
        frame.setLayout(new BorderLayout());
        //agregamos los paneles al frame principal
        frame.setLayout(new BorderLayout());
        frame.add(contruyePanelSuperior(dataVisualizador.getNumeroPelea(), dataVisualizador.getValorApuesta()), BorderLayout.NORTH);
        frame.add(contruyePanelCentral(), BorderLayout.CENTER);
        frame.add(contruyePanelIzquierdo(dataVisualizador.getGalloRojo()), BorderLayout.WEST);
        frame.add(contruyePanelDerecho(dataVisualizador.getGalloAzul()), BorderLayout.EAST);
        //Configuramos el frame
        frame.pack();
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
                System.out.println("Cierra vemtana 1");
                getTimerPrincipal().task.cancel();
                getTimerDerecha().task.cancel();
                getTimerIzquierda().task.cancel();
                getTimerEspuela().task.cancel();
                GlobalScreen.removeNativeKeyListener(nativeKeyListener);
            }

            @Override
            public void windowClosed(WindowEvent e) {
                //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void windowIconified(WindowEvent e) {
                //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void windowDeiconified(WindowEvent e) {
                //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void windowActivated(WindowEvent e) {
                //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void windowDeactivated(WindowEvent e) {
                //To change body of generated methods, choose Tools | Templates.
            }
        });
        construirAlertaGanador(frame);
    }

    @Override
    public void generarEmpate(String tiempoFinal) {
        if (peleaLibre) {
            Inicializador.insertarResultadoPeleaLibre(dataVisualizador.getNumeroPeleaId(), true, null, tiempoFinal);
            Inicializador.actualizarEstadoPeleaLibre(dataVisualizador.getNumeroPeleaId(), EstadoPelea.TERMINADA.getId());
            peleasLibresView.cargarTablaPelasLibres();
        } else {
            Inicializador.insertarResultado(dataVisualizador.getNumeroPeleaId(), true, dataVisualizador.getGalloRojo().getIdGallo(), false, 1, tiempoFinal);
            Inicializador.insertarResultado(dataVisualizador.getNumeroPeleaId(), true, dataVisualizador.getGalloAzul().getIdGallo(), false, 1, tiempoFinal);
            Inicializador.actualizarEstadoPelea(dataVisualizador.getNumeroPeleaId(), EstadoPelea.TERMINADA.getId());
            peleasPactadas.refrescarTabla();
        }

        labelGanador.setBackground(Color.ORANGE);
        labelGanador.setText("EMPATE");
        labelGanador.setVisible(true);
    }

    @Override
    public void generarGanador(String tiempoFinal, boolean ganaIzquierda) {
        if (ganaIzquierda) {
            labelGanador.setBackground(new Color(190, 30, 45, 200));
            labelGanador.setText("GANA ROJO");
            labelGanador.setVisible(true);
            if (peleaLibre) {
                Inicializador.insertarResultadoPeleaLibre(dataVisualizador.getNumeroPeleaId(), false, dataVisualizador.getGalloRojo().getIdGallo(), tiempoFinal);
                Inicializador.actualizarEstadoPeleaLibre(dataVisualizador.getNumeroPeleaId(), EstadoPelea.TERMINADA.getId());
                peleasLibresView.cargarTablaPelasLibres();
            } else {
                Inicializador.insertarResultado(dataVisualizador.getNumeroPeleaId(), false, dataVisualizador.getGalloRojo().getIdGallo(), true, 2, tiempoFinal);
                Inicializador.insertarResultado(dataVisualizador.getNumeroPeleaId(), false, dataVisualizador.getGalloAzul().getIdGallo(), false, 0, tiempoFinal);
                Inicializador.actualizarEstadoPelea(dataVisualizador.getNumeroPeleaId(), EstadoPelea.TERMINADA.getId());
                peleasPactadas.cargarCotejos();
            }
        } else {
            labelGanador.setBackground(new Color(35, 42, 85, 200));
            labelGanador.setText("GANA AZUL");
            labelGanador.setVisible(true);
            if (peleaLibre) {
                Inicializador.insertarResultadoPeleaLibre(dataVisualizador.getNumeroPeleaId(), false, dataVisualizador.getGalloAzul().getIdGallo(), tiempoFinal);
                Inicializador.actualizarEstadoPeleaLibre(dataVisualizador.getNumeroPeleaId(), EstadoPelea.TERMINADA.getId());
                peleasLibresView.cargarTablaPelasLibres();
            } else {
                Inicializador.insertarResultado(dataVisualizador.getNumeroPeleaId(), false, dataVisualizador.getGalloRojo().getIdGallo(), false, 0, tiempoFinal);
                Inicializador.insertarResultado(dataVisualizador.getNumeroPeleaId(), false, dataVisualizador.getGalloAzul().getIdGallo(), true, 2, tiempoFinal);
                Inicializador.actualizarEstadoPelea(dataVisualizador.getNumeroPeleaId(), EstadoPelea.TERMINADA.getId());
                peleasPactadas.cargarCotejos();
            }
        }
    }

    @Override
    public void nativeKeyTyped(NativeKeyEvent e) {
        System.out.println("tipied " + e.paramString());
    }

    @Override

    public void nativeKeyPressed(NativeKeyEvent e) {

        try {
            boolean result = controlesManuales(teclaLiberada, e.getRawCode());
            if (result) {
                return;
            }
            long elapsedTimeP = System.nanoTime() - startPrincipal;
            long convertP = TimeUnit.SECONDS.convert(elapsedTimeP, TimeUnit.NANOSECONDS);
            boolean dobleclickP = convertP == 0;
            startPrincipal = System.nanoTime();
            if (dobleclickP && teclaLiberada == 66 && e.getRawCode() == 66) {
                if (peleaLibre) {
                    Inicializador.actualizarEstadoPeleaLibre(dataVisualizador.getNumeroPeleaId(), EstadoPelea.PELEANDO.getId());
                    peleasLibresView.cargarTablaPelasLibres();
                } else {
                    System.out.println("Pelea a actualizar " + dataVisualizador.getNumeroPeleaId());
                    Inicializador.actualizarEstadoPelea(dataVisualizador.getNumeroPeleaId(), EstadoPelea.PELEANDO.getId());
                    peleasPactadas.refrescarTabla();
                }
                try {
                    getTimerEspuela().setMinutosIniciales(Tiempo.MINUTOS_GENERAR_EMPATE);
                    getTimerEspuela().reiniciar();
                    getTimerEspuela().setIsTimerRunning(false);
                    getTimerPrincipal().start(0, 1000);
                    getTimerPrincipal().setIsTimerRunning(true);
                } catch (Exception ex) {
                    if (getTimerPrincipal().isIsTimerRunning()) {
                        getTimerEspuela().setMinutosIniciales(Tiempo.MINUTOS_CAMBIO_ESPUELA);
                    } else {
                        getTimerEspuela().setMinutosIniciales(Tiempo.MINUTOS_GENERAR_EMPATE);

                    }
                    getTimerEspuela().reiniciar();
                    getTimerEspuela().setIsTimerRunning(false);
                    getTimerPrincipal().setIsTimerRunning(!getTimerPrincipal().isIsTimerRunning());
                }
            }

            if (e.getRawCode() == 33) {
                long elapsedTime = System.nanoTime() - start;
                long convert = TimeUnit.SECONDS.convert(elapsedTime, TimeUnit.NANOSECONDS);
                boolean dobleclick = convert == 0;
                start = System.nanoTime();
                if (getTimerPrincipal().isIsTimerRunning()) {
                    controlRelojIzquierda(dobleclick);
                }
            }

            if (e.getRawCode() == 34) {
                long elapsedTime = System.nanoTime() - start;
                long convert = TimeUnit.SECONDS.convert(elapsedTime, TimeUnit.NANOSECONDS);
                boolean dobleclick = convert == 0;
                start = System.nanoTime();
                if (getTimerPrincipal().isIsTimerRunning()) {
                    controlRelojDerecha(dobleclick);
                }
            }

            if (e.getRawCode() == 27 || e.getRawCode() == 83) {
                System.out.println("espuecla");
                long elapsedTime = System.nanoTime() - start;
                long convert = TimeUnit.SECONDS.convert(elapsedTime, TimeUnit.NANOSECONDS);
                boolean dobleclick = convert == 0;
                start = System.nanoTime();
                controlRelojEspuela(dobleclick);
            }
        } catch (Exception ex) {
            System.out.println("Error timer");
        }
    }

    @Override
    public void nativeKeyReleased(NativeKeyEvent e) {
        teclaLiberada = e.getRawCode();
    }

    private boolean controlesManuales(int teclaLiberada, int teclaPresionada) {
        if (teclaLiberada == 82 && teclaPresionada == 97) {
            //Gana Rojo
            reiniciarTodosLosRelojes();
            generarGanador(getTimerPrincipal().calcularTiempoFinal(), true);
            return true;
        } else if (teclaLiberada == 65 && teclaPresionada == 98) {
            //Gana Azul
            reiniciarTodosLosRelojes();
            generarGanador(getTimerPrincipal().calcularTiempoFinal(), false);
            return true;
        } else if (teclaLiberada == 69 && teclaPresionada == 96) {
            //Empate
            reiniciarTodosLosRelojes();
            generarEmpate(getTimerPrincipal().calcularTiempoFinal());
            return true;
        }
        return false;
    }

    private void controlRelojEspuela(boolean reiniciar) {
        if (reiniciar) {
            if (getTimerPrincipal().isIsTimerRunning()) {
                getTimerEspuela().setMinutosIniciales(Tiempo.MINUTOS_GENERAR_EMPATE);
            } else {
                getTimerEspuela().setMinutosIniciales(Tiempo.MINUTOS_CAMBIO_ESPUELA);
            }
            getTimerEspuela().setIsTimerRunning(false);
            getTimerEspuela().reiniciar();
            return;
        }

//        if (getTimerPrincipal().isIsTimerRunning()) {
//            getTimerEspuela().setMinutosIniciales(Tiempo.MINUTOS_GENERAR_EMPATE);
//        } else {
//            getTimerEspuela().setMinutosIniciales(Tiempo.MINUTOS_GENERAR_EMPATE);
//        }
        try {
            getTimerEspuela().start(0, 1000);
            getTimerEspuela().setIsTimerRunning(true);
        } catch (Exception ex) {
            getTimerEspuela().setIsTimerRunning(!getTimerEspuela().isIsTimerRunning());
        }
    }

    private void controlRelojDerecha(boolean reiniciar) {

        if (reiniciar) {
            getTimerDerecha().setIsTimerRunning(false);
            getTimerDerecha().reiniciar();
            if (getTimerIzquierda().getMinute() == 0 && getTimerIzquierda().getSecond() == 0) {
                getTimerPrincipal().kill();
                generarGanador(getTimerPrincipal().calcularTiempoFinal(), false);
            }
            return;
        }

        try {
            getTimerDerecha().start(0, 1000);
            getTimerDerecha().setIsTimerRunning(true);
        } catch (Exception ex) {
            getTimerDerecha().setIsTimerRunning(!getTimerDerecha().isIsTimerRunning());
        }
    }

    private void controlRelojIzquierda(boolean reiniciar) {
        if (reiniciar) {
            getTimerIzquierda().setIsTimerRunning(false);
            getTimerIzquierda().reiniciar();
            if (getTimerDerecha().getMinute() == 0 && getTimerDerecha().getSecond() == 0) {
                getTimerPrincipal().kill();
                generarGanador(getTimerPrincipal().calcularTiempoFinal(), true);
            }
            return;
        }

        try {
            getTimerIzquierda().start(0, 1000);
            getTimerIzquierda().setIsTimerRunning(true);
        } catch (Exception ex) {
            getTimerIzquierda().setIsTimerRunning(!getTimerIzquierda().isIsTimerRunning());
        }
    }

    private void reiniciarTodosLosRelojes() {
        getTimerPrincipal().setIsTimerRunning(false);
        getTimerIzquierda().setIsTimerRunning(false);
        getTimerDerecha().setIsTimerRunning(false);
        getTimerEspuela().setIsTimerRunning(false);
    }
}
