/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.utilidades;

import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author User
 */
public class TemporizadorTeclado {

    private int minute;
    private int minutosIniciales;
    private int second = 60;
    private Timer timer;
    private boolean isTimerRunning;

    public TemporizadorTeclado() {

        timer = new Timer();
        this.minute = 0;
    }

    public TimerTask task = new TimerTask() {
        @Override
        public void run() {
            if (isTimerRunning) {                
                if (getSecond() == 60) {
                    setMinute(getMinute() - 1);
                }
                if (getSecond() > 0) {                   
                    setSecond(getSecond() - 1);
                } else {
                    setSecond(59);
                    if (getMinute() > 0) {
                        setMinute(getMinute() - 1);
                    } else {
                        setIsTimerRunning(false);
                        kill();
                    }
                }
            }

        }
    }; // fin timertask

    public void start(int timeout, int interval) {
        getTimer().schedule(task, timeout, interval);
        isTimerRunning=true;
    }

    public void kill() {
        getTimer().cancel();
        getTimer().purge();
    }

    public void reiniciar() {
        setMinute(0);
        setSecond(0);
    }

    /**
     * @return the timer
     */
    public Timer getTimer() {
        return timer;
    }

    /**
     * @param timer the timer to set
     */
    public void setTimer(Timer timer) {
        this.timer = timer;
    }

    /**
     * @return the isTimerRunning
     */
    public boolean isIsTimerRunning() {
        return isTimerRunning;
    }

    /**
     * @param isTimerRunning the isTimerRunning to set
     */
    public void setIsTimerRunning(boolean isTimerRunning) {
        this.isTimerRunning = isTimerRunning;
    }

    /**
     * @return the minute
     */
    public int getMinute() {
        return minute;
    }

    /**
     * @param minute the minute to set
     */
    public void setMinute(int minute) {
        this.minute = minute;
    }

    /**
     * @return the second
     */
    public int getSecond() {
        return second;
    }

    /**
     * @param second the second to set
     */
    public void setSecond(int second) {
        this.second = second;
    }

    /**
     * @return the minutosIniciales
     */
    public int getMinutosIniciales() {
        return minutosIniciales;
    }

    /**
     * @param minutosIniciales the minutosIniciales to set
     */
    public void setMinutosIniciales(int minutosIniciales) {
        this.minutosIniciales = minutosIniciales;
    }

}
