/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.utilidades;

/**
 *
 * @author User
 */
public enum EstadoPelea {

    GENERADA(1, "Generada"),
    EN_ESPERA(2, "En espera"),
    PELEANDO(3, "Peleando"),
    TERMINADA(4, "Terminada"),
    PACTADA(5, "Pactada");

    private Integer id;
    private String descripcion;

    private EstadoPelea(Integer id, String descripcion) {
        this.id = id;
        this.descripcion = descripcion;
    }

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public static EstadoPelea finById(Integer id) {
        for (EstadoPelea estadoPelea : EstadoPelea.values()) {
            if (id.equals(estadoPelea.getId())) {
                return estadoPelea;
            }
        }
        return null;
    }
}
