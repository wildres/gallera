/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.utilidades;

/**
 *
 * @author User
 */
public enum TipoGalloEnum {

    GALLO(1),
    POLLO(2);

    private Integer id;

    private TipoGalloEnum(Integer id) {
        this.id = id;

    }

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

}
