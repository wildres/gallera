/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.utilidades;

/**
 *
 * @author User
 */
public enum ParametrosGeneralesEnum {

    CANTIDAD_GALLOS_X_FRENTE(1, "2", "Cantidad de gallos por frente"),
    NOMBRE_TORNEO(2, "No hay nombre parametrizado", "Nombre del torneo"),
    VALOR_APUESTA(3, "0", "Valor de la apuesta"),
    TIEMPO_PELEA(4, "0", "Tiempo de la pelea"),
    NOMBRE_GALLERA(5, "No hay nombre parametrizado", "Nombre de la gallera"),
    IP_REMOTA(6, "0.0.0.0", "Ip de la base de datos remota");

    private ParametrosGeneralesEnum(Integer id, String valor, String descripcion) {
        this.id = id;
        this.valor = valor;
        this.descripcion = descripcion;
    }

    private Integer id;
    private String valor;
    private String descripcion;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return the valor
     */
    public String getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(String valor) {
        this.valor = valor;
    }

}
