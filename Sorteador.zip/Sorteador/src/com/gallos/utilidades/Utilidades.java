/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.utilidades;

import com.gallos.entidades.Cotejo;
import com.gallos.entidades.Cuerda;
import com.gallos.entidades.Frente;
import com.gallos.entidades.Gallo;
import com.gallos.entidades.Region;
import com.gallos.entidades.Reporte;
import com.gallos.entidades.ReporteLibres;
import com.gallos.inicializador.Inicializador;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;
import com.itextpdf.text.pdf.draw.VerticalPositionMark;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class Utilidades {

    private static final float[] MEDIDAS = {0.65f, 2.25f, 0.65f, 1.00f, 0.70f, 0.55f, 0.55f, 0.70f, 0.65f, 0.55f};
    private static final float[] MEDIDAS_LIBRES = {0.65f, 2.25f, 0.65f, 1.00f, 0.70f, 0.55f, 0.55f, 0.70f, 0.65f, 0.55f};
    private static final String RUTA_ARCHIVOS = "C:\\";
    private static final String ABRIR_HTML = "<html><body>";
    private static final String CERRAR_HTML = "</body></html>";
    private static final String ABRIR_SPAN = "<span style='font-size:70'>";
    private static final String CERRAR_SPAN = "</span><br>";

    public static BigDecimal convertirPeso(String peso) {
        try {
            String[] array = peso.split(",");
            if (array.length >= 2 && Integer.valueOf(array[1]) <= 9) {
                String nuevoValor = null;
                if (array[1].length() >= 2) {
                    nuevoValor = array[0] + "," + array[1];
                } else {
                    nuevoValor = array[0] + ",0" + array[1];
                }

                return new BigDecimal(nuevoValor.replace(",", "."));
            } else {
                System.out.println("entra 2");
                return new BigDecimal(peso.replace(",", "."));
            }
        } catch (NumberFormatException ex) {
            System.out.println("Error convertirPeso " + ex.getMessage());
        }
        return BigDecimal.ZERO;
    }

    public static BigDecimal darFormatoVisualPeso(BigDecimal peso) {
        try {
            String[] array = peso.toPlainString().replace(".", ",").split(",");
            if (array.length >= 2 && Integer.valueOf(array[1].substring(0, 1)) == 0) {
                String nuevoValor = array[0] + "," + Integer.valueOf(array[1]);
                return new BigDecimal(nuevoValor.replace(",", "."));
            } else {
                return peso;
            }
        } catch (NumberFormatException ex) {
            System.out.println("Error darFormatoVisualPeso " + ex.getMessage());
        }
        return BigDecimal.ZERO;
    }

    public static String gramosAOnzas(int gramos) {
        String resultado = "";
        try {
            DecimalFormat formato1 = new DecimalFormat("#.000");
            float result = gramos * 0.0352739619f;
            resultado = formato1.format(result);
        } catch (Exception ex) {
            System.out.println("Error convirtinedo gramos a onzas " + ex.getMessage());
        }
        return resultado;
    }

    public static String librasAgramos(float libras) {
        String resultado = "";
        try {
            DecimalFormat formato1 = new DecimalFormat("###0");
            double result = libras * 453.59237f;
            resultado = formato1.format(result);
        } catch (Exception ex) {
            System.out.println("Error convirtinedo gramos a onzas " + ex.getMessage());
        }
        return resultado;
    }

    public static int generarNumero(int hasta) {
        if (hasta > 0) {
            Random r = new Random();
            return r.nextInt(hasta);
        } else {
            return 0;
        }

//        return (int) Math.floor(Math.random() * (0 - hasta + 1) + hasta);
    }

    public static List<Gallo> copiarLista(List<Gallo> list, int desde) {
        List<Gallo> listResult = new ArrayList<>();
        for (int i = desde; i < list.size(); i++) {
            if (list.get(i).isLibre()) {
                listResult.add(list.get(i));
            }
        }
        return listResult;
    }

    public static boolean between(int base, double num1, double num2) {
        return base >= num1 && base <= num2;
    }

    public static boolean aplicaTolerancia(int tolerancia, int base) {
        return base <= tolerancia;
    }

    public static List<Gallo> removerGallos(List<Gallo> list, Integer... idGallos) {
        for (Integer idGallo : idGallos) {
            for (Gallo gallo : list) {
                if (idGallo.equals(gallo.getIdGallo())) {
                    list.remove(gallo);
                }
            }
        }
        return list;
    }

    public static Gallo encontrarRival(List<Gallo> listGallos, Gallo gallo1, int tolerancia, Map<Cuerda, Cuerda> mapExcepcionCuerda,
            Map<Region, Region> mapExcepcionRegion) {
        Gallo gallo2 = null;
        while (true) {
            int indice = generarNumero(listGallos.size() - 1);
            if (listGallos.size() > 0) {
                gallo2 = listGallos.get(indice);
                boolean esPareja = false;
                if (!gallo1.getCuerda().getIdCuerda().equals(gallo2.getCuerda().getIdCuerda())) {
                    if (gallo1.getPesoGramos().intValue() != gallo2.getPesoGramos().intValue()) {
                        double result = (double) tolerancia / 10;
                        if (gallo1.getPesoGramos().intValue() > gallo2.getPesoGramos().intValue()) {
                            BigDecimal peso = Utilidades.darFormatoVisualPeso(gallo2.getPesoGramos());
                            String margenTolerancia = String.valueOf(result);
                            gallo2.setPesoGramos(peso.add(new BigDecimal(margenTolerancia)));
                        } else if (gallo2.getPesoGramos().intValue() > gallo1.getPesoGramos().intValue()) {
                            BigDecimal peso = Utilidades.darFormatoVisualPeso(gallo1.getPesoGramos());
                            String margenTolerancia = String.valueOf(result);
                            gallo1.setPesoGramos(peso.add(new BigDecimal(margenTolerancia)));
                        }
                    }
                    int peso1 = extraerDecimal(gallo1.getPesoGramos());
                    int peso2 = extraerDecimal(gallo2.getPesoGramos());
                    int diferencia = peso1 - peso2;
                    if (diferencia < 0) {
                        diferencia = diferencia * -1;
                    }
                    Integer resultadoToleranciaMarca = gallo1.getMarca() - gallo2.getMarca();
                    if (resultadoToleranciaMarca < 0) {
                        resultadoToleranciaMarca = resultadoToleranciaMarca * -1;
                    }
                    if (Utilidades.aplicaTolerancia(tolerancia, diferencia)
                            && ((gallo1.getPesoGramos().intValue() == gallo2.getPesoGramos().intValue()))
                            && !aplicaExpecionCuerda(gallo1.getCuerda(), gallo2.getCuerda(), mapExcepcionCuerda)
                            && !aplicaExpecionRegion(gallo1.getRegion(), gallo2.getRegion(), mapExcepcionRegion)
                            && gallo1.getTipo().getIdTipoDeGallo().equals(gallo2.getTipo().getIdTipoDeGallo())
                            && gallo1.esPava() == gallo2.esPava()) {
                        //La marca solo aplica para los pollos
                        if (gallo1.getTipo().getIdTipoDeGallo() == 2) {
                            //Lo tolerncia de la marca es de 1
                            if (Utilidades.aplicaTolerancia(1, resultadoToleranciaMarca)) {
                                esPareja = true;
                            }
                        } else {
                            esPareja = true;
                        }
                    } else {
                        listGallos.remove(gallo2);
                        gallo2 = null;
                    }
                } else {
                    listGallos.remove(gallo2);
                    gallo2 = null;
                }

                if (esPareja) {
                    break;
                } else {
                    listGallos.remove(gallo2);
                }
                if (listGallos.isEmpty()) {
                    break;
                }
            } else {
                break;
            }
        }
        return gallo2;
    }

    public static int extraerDecimal(BigDecimal peso) {
        String valor[] = peso.toPlainString().replace(".", ",").split(",");
        return Integer.valueOf(valor[1]);
    }

    private static boolean aplicaExpecionCuerda(Cuerda cuerda1, Cuerda cuerda2, Map<Cuerda, Cuerda> map) {
        for (Map.Entry<Cuerda, Cuerda> entry : map.entrySet()) {
            Cuerda key = entry.getKey();
            Cuerda value = entry.getValue();
            if (cuerda1.getIdCuerda().equals(key.getIdCuerda())
                    && cuerda2.getIdCuerda().equals(value.getIdCuerda())) {
                return true;
            }
        }
        return false;
    }

    private static boolean aplicaExpecionRegion(Region region1, Region region2, Map<Region, Region> mapRegion) {
        for (Map.Entry<Region, Region> entry : mapRegion.entrySet()) {
            Region key = entry.getKey();
            Region value = entry.getValue();
            System.out.println("key " + key.getId() + " value " + value.getId() + " region " + region1);
            if (region1.getId().equals(key.getId())
                    && region2.getId().equals(value.getId())) {
                return true;
            }
        }
        return false;
    }

    public static void imprimirGallosPorCuerda(Cuerda cuerda, List<Gallo> listGallos) {
        try {
            String nombreDoumento = "Gallos_" + cuerda.getNombre().trim() + ".pdf";
            Document documento = crearDocumento(nombreDoumento);
            Paragraph titulo1 = new Paragraph("LISTADO DE GALLOS INSCRITOS", FontFactory.getFont("arial", // fuente
                    12, // tamaño
                    Font.BOLD, // estilo
                    BaseColor.BLACK));
            titulo1.setAlignment(Element.ALIGN_CENTER);
            documento.add(titulo1);
            LineSeparator separador = new LineSeparator();
            documento.add(new Chunk(separador));
            documento.add(crearEncabezadoCuerda(cuerda.getNombre()));
            // color
            PdfPTable tabla = crearTablaCuerda();

            for (int i = 0; i < listGallos.size(); i++) {
                Gallo gallo = listGallos.get(i);
                addCell(gallo.getIdGallo().toString(), tabla);
                addCell(gallo.getAnillo(), tabla);
                addCell(gallo.getTipo().getNombre(), tabla);
                addCell(gallo.getPlumaje().getNombre(), tabla);
                addCell(gallo.getPesoGramos().toString(), tabla);
                addCell(gallo.getMarca().toString(), tabla);
                addCell(gallo.getRegion().getNombre(), tabla);
            }
            tabla.setSpacingBefore(10);
            documento.add(tabla);
            documento.close();
//            System.out.println("Genrado "+);
            Desktop.getDesktop().open(new File(RUTA_ARCHIVOS + nombreDoumento));
        } catch (Exception ex) {
            System.out.println("Error creando domcnetoGallosPoCuerda " + ex.getMessage());
        }
    }

    public static void imprimirCuerdas(List<Cuerda> listCuerdas, String nombreTitulo, boolean addSubtitulo) {
        try {
            String nombreArchivo = "todaslascuerdas.pdf";
            Document documento = crearDocumento(nombreArchivo);
            if (nombreTitulo == null) {
                nombreTitulo = "LISTADO DE GALLOS INSCRITOS";
            } else {
                nombreTitulo = "Cuerda: " + nombreTitulo.toUpperCase();
            }

            Paragraph nombreTorneo = new Paragraph(Inicializador.cache.get(ParametrosGeneralesEnum.NOMBRE_TORNEO.getId()).getValor(), FontFactory.getFont("arial", // fuente
                    12, // tamaño
                    Font.BOLD, // estilo
                    BaseColor.RED));
            nombreTorneo.setAlignment(Element.ALIGN_CENTER);
            documento.add(nombreTorneo);
            Paragraph titulo1 = new Paragraph(nombreTitulo, FontFactory.getFont("arial", // fuente
                    11, // tamaño
                    Font.BOLD, // estilo
                    BaseColor.BLACK));
            titulo1.setAlignment(Element.ALIGN_CENTER);
            documento.add(titulo1);
            LineSeparator separador = new LineSeparator();
            documento.add(new Chunk(separador));
            for (Cuerda cuerda : listCuerdas) {
                if (addSubtitulo) {
                    documento.add(crearEncabezadoCuerda(cuerda.getNombre()));
                }

                List<Frente> listFrentes = Inicializador.consultarFrentesPorCuerda(cuerda.getIdCuerda(), Inicializador.consultarTorneoActivo().getId());
                for (Frente frente : listFrentes) {
                    documento.add(crearNombreFrente(frente.getNombre()));
                    List<Gallo> listGallos = Inicializador.consultarGallosPorFrente(frente.getNumeroFrente(), cuerda.getIdCuerda(), Inicializador.consultarTorneoActivo().getId());
// color
                    PdfPTable tabla = crearTablaCuerda();
                    for (int i = 0; i < listGallos.size(); i++) {
                        Gallo gallo = listGallos.get(i);
                        addCell(gallo.getAnillo(), tabla);
                        addCell(gallo.getTipo().getNombre(), tabla);
                        addCell(gallo.getPlumaje().getNombre(), tabla);
                        addCell(gallo.getPesoGramos().toString(), tabla);
                        addCell(gallo.getMarca().toString(), tabla);
                        addCell(gallo.getRegion().getNombre(), tabla);
                        addCell(gallo.getFrente().getNumeroFrente().toString(), tabla);
                        addCell(gallo.getJaula().toString(), tabla);
                    }
                    tabla.setSpacingBefore(10);
                    documento.add(tabla);
                }
            }
            documento.close();
            System.out.println("Genrado");
            Desktop.getDesktop().open(new File(RUTA_ARCHIVOS + nombreArchivo));
        } catch (Exception ex) {
            System.out.println("Error creando domcnetoCuerdas " + ex.getMessage());
        }
    }

    private static Document crearDocumento(String nombre) {
        Document documento = new Document();
        try {
            
            File file = new File(RUTA_ARCHIVOS + nombre);
            if (file.exists()) {
                file.delete();
            } else {
                file.createNewFile();
            }
            FileOutputStream ficheroPdf = new FileOutputStream(file);
            PdfWriter.getInstance(documento, ficheroPdf).setInitialLeading(0);
            documento.open();
            Chunk glue = new Chunk(new VerticalPositionMark());
            Paragraph p = new Paragraph("Text to the left");
            p.add(new Chunk(glue));
            Date date = new Date();
            DateFormat fecha = new SimpleDateFormat("yyyy-MM-dd");
            String fechaString = fecha.format(date);
            p.add(fechaString);
            Paragraph p2 = new Paragraph();
            p2.add(new Chunk(glue));
            DateFormat hora = new SimpleDateFormat("HH:mm:ss a");
            String horaString = hora.format(date);
            p2.add(horaString);
            documento.add(p);
            documento.add(p2);
        } catch (Exception ex) {
            System.out.println("Erroc reando docuento pdf " + ex.getMessage());
        }
        return documento;
    }

    private static PdfPTable crearTablaCuerda() {
        PdfPTable tabla = new PdfPTable(8);
        String[] encabezado = {"Anillo", "Tipo", "Color", "Peso", "Marca", "Región", "Frente", "Jaula"};
        for (String head : encabezado) {
            PdfPCell cell = new PdfPCell();
            Phrase firstLine = new Phrase(head, FontFactory.getFont("arial", // fuente
                    8, // tamaño
                    Font.BOLD, // estilo
                    BaseColor.BLACK));
            cell.addElement(firstLine);
            tabla.addCell(cell);
        }
        return tabla;
    }

    private static PdfPTable crearEncabezadoTablaPeleas() throws DocumentException {
        PdfPTable tabla = new PdfPTable(10);
        tabla.setWidths(MEDIDAS);
        String[] encabezado = {"Orden", "Cuerda", "Frente", "Región", "Color", "Peso", "Jaula", "Marca", "Tipo", "Anillo"};
        for (String head : encabezado) {
            PdfPCell cell = new PdfPCell();
            Phrase firstLine = new Phrase(head, FontFactory.getFont("arial", // fuente
                    8, // tamaño
                    Font.BOLD, // estilo
                    BaseColor.BLACK));
            cell.addElement(firstLine);
            tabla.addCell(cell);
        }
        return tabla;
    }

    private static PdfPTable crearEncabezadoTablaPeleasLibres() throws DocumentException {
        PdfPTable tabla = new PdfPTable(4);
        String[] encabezado = {"N° Pelea", "Ganador", "Minutos", "Segundos"};
        for (String head : encabezado) {
            PdfPCell cell = new PdfPCell();
            Phrase firstLine = new Phrase(head, FontFactory.getFont("arial", // fuente
                    8, // tamaño
                    Font.BOLD, // estilo
                    BaseColor.BLACK));
            cell.addElement(firstLine);
            tabla.addCell(cell);
        }
        return tabla;
    }

    private static PdfPTable crearRegistroPelea(Cotejo cotejo) {
        PdfPTable tabla = new PdfPTable(10);
        try {
            tabla.setWidths(MEDIDAS);
            Gallo gallo1 = cotejo.getGallo1();
            String[] registro = {cotejo.getId().toString(), gallo1.getCuerda().getNombre(),
                gallo1.getFrente().getNumeroFrente().toString(), gallo1.getRegion().getNombre(),
                gallo1.getPlumaje().getNombre(), darFormatoVisualPeso(gallo1.getPesoGramos()).toString(),
                gallo1.getJaula().toString(),
                (gallo1.getMarca().equals(0) ? "N/A" : gallo1.getMarca().toString()),
                gallo1.getTipo().getNombre(), gallo1.getAnillo()};
            for (String valor : registro) {
                PdfPCell cell = new PdfPCell();
                Phrase firstLine = new Phrase(valor, FontFactory.getFont("arial", // fuente
                        8, // tamaño
                        Font.NORMAL, // estilo
                        BaseColor.BLACK));
                cell.addElement(firstLine);
                tabla.addCell(cell);
            }
            Gallo gallo2 = cotejo.getGallo2();
            String[] registro2 = {cotejo.getId().toString(), gallo2.getCuerda().getNombre(),
                gallo2.getFrente().getNumeroFrente().toString(), gallo2.getRegion().getNombre(),
                gallo2.getPlumaje().getNombre(), darFormatoVisualPeso(gallo2.getPesoGramos()).toString(),
                gallo2.getJaula().toString(), (gallo2.getMarca().equals(0) ? "N/A" : gallo2.getMarca().toString()),
                gallo2.getTipo().getNombre(), gallo2.getAnillo()};
            for (String valor : registro2) {
                PdfPCell cell = new PdfPCell();
                Phrase firstLine = new Phrase(valor, FontFactory.getFont("arial", // fuente
                        8, // tamaño
                        Font.NORMAL, // estilo
                        BaseColor.BLACK));
                cell.addElement(firstLine);
                tabla.addCell(cell);
            }
            tabla.setSpacingBefore(10);
        } catch (DocumentException ex) {
            System.out.println("Erro creando registreo " + ex.getMessage());
        }
        return tabla;
    }

    private static PdfPTable crearRegistroPelea(ReporteLibres peleaLibre) {
        PdfPTable tabla = new PdfPTable(4);
        try {
            Object[] registro = {peleaLibre.getNroPelea(), peleaLibre.getGanador(),
                peleaLibre.getMinutos(), peleaLibre.getSegundos()};
            for (Object valor : registro) {
                PdfPCell cell = new PdfPCell();
                Phrase firstLine = new Phrase(valor.toString(), FontFactory.getFont("arial", // fuente
                        8, // tamaño
                        Font.NORMAL, // estilo
                        BaseColor.BLACK));
                cell.addElement(firstLine);
                tabla.addCell(cell);
            }
        } catch (Exception ex) {
            System.out.println("Erro creando registreo " + ex.getMessage());
        }
        return tabla;
    }

    private static Paragraph crearEncabezadoCuerda(String nombreCuerda) {
        Paragraph titulo2 = new Paragraph("Listado Gallos de Cuerda: " + nombreCuerda.toUpperCase(),
                FontFactory.getFont("arial", // fuente
                        10, // tamaño
                        Font.BOLD, // estilo
                        BaseColor.BLACK));
        titulo2.setLeading(30);
        return titulo2;
    }

    private static Paragraph crearNombreFrente(String nombreFrente) {
        Paragraph titulo2 = new Paragraph("        Frente: " + nombreFrente.toUpperCase(),
                FontFactory.getFont("arial", // fuente
                        9, // tamaño
                        Font.NORMAL, // estilo
                        BaseColor.BLUE));
        titulo2.setLeading(20);
        return titulo2;
    }

    private static void addCell(String value, PdfPTable tabla) {
        Font fontNormal = FontFactory.getFont("arial", 7, Font.NORMAL, BaseColor.BLACK);
        PdfPCell cellId = new PdfPCell();
        Phrase phraseId = new Phrase(value, fontNormal);
        cellId.addElement(phraseId);
        tabla.addCell(cellId);
    }

    public static void imprimirPeleas(List<Cotejo> listCotejos) {
        try {
            String nombreArchivo = "peleas.pdf";
            Document documento = crearDocumento(nombreArchivo);
            Paragraph titulo1 = new Paragraph("LISTADO DE PELEAS ORDENADAS", FontFactory.getFont("arial", // fuente
                    12, // tamaño
                    Font.BOLD, // estilo
                    BaseColor.BLACK));
            titulo1.setAlignment(Element.ALIGN_CENTER);
            documento.add(titulo1);
            LineSeparator separador = new LineSeparator();
            documento.add(new Chunk(separador));
            PdfPTable tabla = crearEncabezadoTablaPeleas();
            tabla.setSpacingBefore(10);
            documento.add(tabla);
            for (Cotejo cotejo : listCotejos) {
                documento.add(crearRegistroPelea(cotejo));
            }
            documento.close();
            Desktop.getDesktop().open(new File(RUTA_ARCHIVOS + nombreArchivo));
        } catch (Exception ex) {
            System.out.println("Error creando domcnetoPeleas " + ex.getMessage());
        }
    }

    public static void imprimirPeleasLibres(List<ReporteLibres> listResultados) {
        try {
            String nombreArchivo = "peleasLibres.pdf";
            Document documento = crearDocumento(nombreArchivo);
            Paragraph titulo1 = new Paragraph("LISTADO DE PELEAS ORDENADAS", FontFactory.getFont("arial", // fuente
                    12, // tamaño
                    Font.BOLD, // estilo
                    BaseColor.BLACK));
            titulo1.setAlignment(Element.ALIGN_CENTER);
            documento.add(titulo1);
            LineSeparator separador = new LineSeparator();
            documento.add(new Chunk(separador));
            PdfPTable tabla = crearEncabezadoTablaPeleasLibres();
            tabla.setSpacingBefore(10);
            documento.add(tabla);
            System.out.println("listResultados " + listResultados.size());
            for (ReporteLibres peleaLibre : listResultados) {
                documento.add(crearRegistroPelea(peleaLibre));
            }
            documento.close();
            Desktop.getDesktop().open(new File(RUTA_ARCHIVOS + nombreArchivo));
        } catch (Exception ex) {
            System.out.println("Error creando domcnetoPeleas " + ex.getMessage());
        }
    }

    public static String hacerValidacionesGenerales(boolean peleaLibre) {
        int minutos = Integer.valueOf(Inicializador.cache.get(ParametrosGeneralesEnum.TIEMPO_PELEA.getId()).getValor());
        String nombreGallera = Inicializador.cache.get(ParametrosGeneralesEnum.NOMBRE_GALLERA.getId()).getValor();
        if (minutos == 0) {
            return "No hay tiempo de pelea parametrizado";
        } else if (nombreGallera == null || nombreGallera.length() == 0) {
            return "No hay nombre de la gallera parametrizado";
        }
        return null;
    }

    public static void mostrarMensaje(String mensaje, int tipoError) {
        JOptionPane.showMessageDialog(null, mensaje, "Mensaje", tipoError);
    }

    public static String convertiraHTML(String mensaje) {
        StringBuilder cadena = new StringBuilder();
        List<String> listCadenas = new ArrayList<>();
        try {
            String[] array = mensaje.split(" ");
            switch (array.length) {
                case 1:
                    if (array[0].length() <= 14) {
                        return mensaje;
                    } else {
                        listCadenas.add(array[0].substring(0, 14));
                        listCadenas.add(array[0].substring(14, array[0].length()));
                    }
                    break;
                case 2:
                    if ((array[0].length() + array[1].length()) < 14) {
                        listCadenas.add(array[0] + " " + array[1]);
                    } else {
                        listCadenas.add(array[0]);
                        listCadenas.add(array[1]);
                    }
                    break;
                case 3:
                    if ((array[0].length() + array[1].length()) < 14) {
                        listCadenas.add(array[0] + " " + array[1]);
                        listCadenas.add(" " + array[2]);
                    } else {
                        listCadenas.add((array[0] + " " + array[1]).substring(0, 12));
                        listCadenas.add((array[0] + " " + array[1]).substring(12) + " " + array[2]);
                    }
                    break;
                default:
                    listCadenas.add(mensaje.substring(0, 13));
                    listCadenas.add(mensaje.substring(13));
                    break;
            }

            if (listCadenas.size() > 1) {
                cadena.append(ABRIR_HTML);
                for (String string : listCadenas) {
                    cadena.append(ABRIR_SPAN);
                    cadena.append(string);
                    cadena.append(CERRAR_SPAN);
                }
                cadena.append(CERRAR_HTML);
            } else {
                return mensaje;
            }
            return cadena.toString();
        } catch (Exception ex) {
            System.out.println("Error " + ex.getMessage());
            return mensaje;
        }
    }

}
