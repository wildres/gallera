/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.utilidades;

import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author User
 */
public class Temporizador {

    private int minute;
    private int minutosIniciales;
    private int second = 60;
    private Timer timer;
    private boolean isTimerRunning;
    private Java2sBevelText jLabel;
    private TipoReloj tipoReloj;
    private Reloj reloj;
    private Display display;

    public Temporizador(final Java2sBevelText jLabel, TipoReloj tipoReloj, Reloj reloj, int minutos) {

        timer = new Timer();
        this.minute = minutos;
        String tiempo = minutos < 9 ? "0" + String.valueOf(minutos) : String.valueOf(minutos);
        jLabel.setText(tiempo + ":00");
        minutosIniciales = this.minute;
        this.jLabel = jLabel;
        this.tipoReloj = tipoReloj;
        this.reloj = reloj;
        this.display = (Display)reloj;
    }

    public String calcularTiempoFinal() {
        int minutoFinal = minutosIniciales - (minute + 1);
        int segundoFinal = 60 - second;
        String tiempo = minutoFinal > 9 ? String.valueOf(minutoFinal) : "0" + minutoFinal;
        return tiempo + ":" + segundoFinal;
    }

    public TimerTask task = new TimerTask() {
        @Override
        public void run() {            
            if (isTimerRunning) {                    
                if (getSecond() == 60) {
                    setMinute(getMinute() - 1);
                }
                if (getSecond() > 0) {
                    setSecond(getSecond() - 1);
                } else {
                    setSecond(59);
                    if (getMinute() > 0) {
                        setMinute(getMinute() - 1);
                    } else {
                        setIsTimerRunning(false);
                        kill();
                    }
                }
                String fullHour = "";
                fullHour += (getMinute() > 9) ? "" + getMinute() : "0" + getMinute();
                fullHour += (getSecond() > 9) ? ":" + getSecond() : ":0" + getSecond();
                jLabel.setText(fullHour);
                if (TipoReloj.IZQUIERDA.equals(tipoReloj)) {
                    if (minute == 0 && second == 0) {
                        isTimerRunning = false;
                        if (!reloj.getTimerDerecha().isIsTimerRunning()) {
                            reloj.getTimerPrincipal().setIsTimerRunning(false);
                            if (reloj.getTimerDerecha().getMinute() == 0 && reloj.getTimerDerecha().getSecond() == 0) {
                                reloj.generarEmpate(reloj.getTimerPrincipal().calcularTiempoFinal());
                            } else {
                                reloj.generarGanador(reloj.getTimerPrincipal().calcularTiempoFinal(), false);
                            }
                        }
                    }
                }

                if (TipoReloj.DERECHA.equals(tipoReloj)) {
                    if (minute == 0 && second == 0) {
                        isTimerRunning = false;
                        if (!reloj.getTimerIzquierda().isIsTimerRunning()) {
                            reloj.getTimerPrincipal().setIsTimerRunning(false);
                            if (reloj.getTimerIzquierda().getMinute() == 0 && reloj.getTimerIzquierda().getSecond() == 0) {
                                reloj.generarEmpate(reloj.getTimerPrincipal().calcularTiempoFinal());
                            } else {
                                reloj.generarGanador(reloj.getTimerPrincipal().calcularTiempoFinal(), true);
                            }
                        }
                    }
                }

                if (TipoReloj.PRINCPAL.equals(tipoReloj)) {
                    if (minute == 0 && second == 0) {
                        isTimerRunning = false;
                        if (!reloj.getTimerEspuela().isIsTimerRunning()) {
                            if (!reloj.getTimerDerecha().isIsTimerRunning() && !reloj.getTimerIzquierda().isIsTimerRunning()) {
                                reloj.generarEmpate(reloj.getTimerPrincipal().calcularTiempoFinal());
                            }
                        }
                    }
                }

                if (TipoReloj.ESPUELA.equals(tipoReloj)) {
                    if (reloj.getTimerPrincipal().isIsTimerRunning()) {
                        if (minute == 0 && second == 0) {
                            isTimerRunning = false;
                            reloj.getTimerPrincipal().setIsTimerRunning(false);
                            reloj.generarEmpate(reloj.getTimerPrincipal().calcularTiempoFinal());
                        }
                    } else {
                        if (minute == 0 && second == 0) {
                            isTimerRunning = false;
                        }
                    }
                }
            }

        }
    }; // fin timertask

    public void start(int timeout, int interval) {
        getTimer().schedule(task, timeout, interval);
    }

    public void kill() {
        getTimer().cancel();
        getTimer().purge();
    }

    public void reiniciar() {
        if (!TipoReloj.PRINCPAL.equals(tipoReloj)) {
            setMinute(getMinutosIniciales());
            setSecond(0);
        } else {
            setMinute(getMinutosIniciales());
            setSecond(60);
        }
        String fullHour = "";
        fullHour += (getMinute() > 9) ? "" + getMinute() : "0" + getMinute();
        fullHour += (getSecond() > 9) ? ":" + getSecond() : ":0" + getSecond();
        jLabel.setText(fullHour);
    }

    public void reiniciar(int minutos) {
        setMinute(minutos);
        setSecond(0);
        String fullHour = "";
        fullHour += (getMinute() > 9) ? "" + getMinute() : "0" + getMinute();
        fullHour += (getSecond() > 9) ? ":" + getSecond() : ":0" + getSecond();
        jLabel.setText(fullHour);
    }

    /**
     * @return the timer
     */
    public Timer getTimer() {
        return timer;
    }

    /**
     * @param timer the timer to set
     */
    public void setTimer(Timer timer) {
        this.timer = timer;
    }

    /**
     * @return the isTimerRunning
     */
    public boolean isIsTimerRunning() {
        return isTimerRunning;
    }

    /**
     * @param isTimerRunning the isTimerRunning to set
     */
    public void setIsTimerRunning(boolean isTimerRunning) {
        this.isTimerRunning = isTimerRunning;
    }

    /**
     * @return the minute
     */
    public int getMinute() {
        return minute;
    }

    /**
     * @param minute the minute to set
     */
    public void setMinute(int minute) {
        this.minute = minute;
    }

    /**
     * @return the second
     */
    public int getSecond() {
        return second;
    }

    /**
     * @param second the second to set
     */
    public void setSecond(int second) {
        this.second = second;
    }

    /**
     * @return the minutosIniciales
     */
    public int getMinutosIniciales() {
        return minutosIniciales;
    }

    /**
     * @param minutosIniciales the minutosIniciales to set
     */
    public void setMinutosIniciales(int minutosIniciales) {
        this.minutosIniciales = minutosIniciales;
    }

}
