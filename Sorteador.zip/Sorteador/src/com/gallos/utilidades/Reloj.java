/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.utilidades;

import javax.swing.JFrame;

/**
 *
 * @author User
 */
public abstract class Reloj extends JFrame {

    private Temporizador timerPrincipal;
    private Temporizador timerIzquierda;
    private Temporizador timerDerecha;
    private Temporizador timerEspuela;

    public abstract void generarEmpate(String tiempoFinal);

    public abstract void generarGanador(String tiempoFinal, boolean ganaIzquierda);

    /**
     * @return the timerPrincipal
     */
    public Temporizador getTimerPrincipal() {
        return timerPrincipal;
    }

    /**
     * @param timerPrincipal the timerPrincipal to set
     */
    public void setTimerPrincipal(Temporizador timerPrincipal) {
        this.timerPrincipal = timerPrincipal;
    }

    /**
     * @return the timerIzquierda
     */
    public Temporizador getTimerIzquierda() {
        return timerIzquierda;
    }

    /**
     * @param timerIzquierda the timerIzquierda to set
     */
    public void setTimerIzquierda(Temporizador timerIzquierda) {
        this.timerIzquierda = timerIzquierda;
    }

    /**
     * @return the timerDerecha
     */
    public Temporizador getTimerDerecha() {
        return timerDerecha;
    }

    /**
     * @param timerDerecha the timerDerecha to set
     */
    public void setTimerDerecha(Temporizador timerDerecha) {
        this.timerDerecha = timerDerecha;
    }

    /**
     * @return the timerEspuela
     */
    public Temporizador getTimerEspuela() {
        return timerEspuela;
    }

    /**
     * @param timerEspuela the timerEspuela to set
     */
    public void setTimerEspuela(Temporizador timerEspuela) {
        this.timerEspuela = timerEspuela;
    }

}
