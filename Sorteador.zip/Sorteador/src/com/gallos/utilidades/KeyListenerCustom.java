/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.utilidades;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 *
 * @author User
 */
public class KeyListenerCustom implements KeyListener {

    @Override
    public void keyTyped(KeyEvent e) {
        System.out.println("type");
    }

    @Override
    public void keyPressed(KeyEvent e) {
        System.out.println("oprime ");
    }

    @Override
    public void keyReleased(KeyEvent e) {
        System.out.println("Libera");
    }

}
