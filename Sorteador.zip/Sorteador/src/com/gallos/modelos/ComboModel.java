/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.modelos;

import java.util.List;
import javax.swing.AbstractListModel;

/**
 *
 * @author User
 */
public class ComboModel extends AbstractListModel implements javax.swing.ComboBoxModel {
    
    private Item item;
    private List<Item> list;
    
    public ComboModel(List<Item> list){
        this.list=list;
    }

    @Override
    public int getSize() {
        return list.size();
    }

    @Override
    public Object getElementAt(int index) {
        return list.get(index);
    }

    @Override
    public void setSelectedItem(Object anItem) {
        item=(Item)anItem;
    }

    @Override
    public Object getSelectedItem() {
         return item;
    }
    
    
    
}
