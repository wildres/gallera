/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.modelos;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class ModeloDatos extends DefaultTableModel {

    private String[] titulos;
    private Object[][] datos;
    private boolean editable;

    public ModeloDatos(Object[][] datos, String[] titulos, boolean editable) {
        super();
        this.titulos = titulos;
        this.datos = datos;
        setDataVector(datos, titulos);
        this.editable = editable;
    }

    @Override
    public boolean isCellEditable(int row, int column) {
        return this.editable;
    }
}
