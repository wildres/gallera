/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.entidades;

/**
 *
 * @author User
 */
public class DataVisualizador {

    private int numeroPelea;
    private String valorApuesta;
    private String nombreGallera;
    private Gallo galloRojo;
    private Gallo galloAzul;

    public DataVisualizador(int numeroPelea, String valorApuesta, String nombreGallera, 
            Gallo galloRojo, Gallo galloAzul) {
        this.numeroPelea = numeroPelea;
        this.valorApuesta = valorApuesta;
        this.nombreGallera = nombreGallera;
        this.galloRojo = galloRojo;
        this.galloAzul = galloAzul;
    }

    /**
     * @return the numeroPelea
     */
    public String getNumeroPelea() {
        return numeroPelea < 9 ? "0" + numeroPelea : String.valueOf(numeroPelea);
    }

    /**
     * @param numeroPelea the numeroPelea to set
     */
    public void setNumeroPelea(int numeroPelea) {
        this.numeroPelea = numeroPelea;
    }

    /**
     * @return the valorApuesta
     */
    public String getValorApuesta() {
        return valorApuesta;
    }

    /**
     * @param valorApuesta the valorApuesta to set
     */
    public void setValorApuesta(String valorApuesta) {
        this.valorApuesta = valorApuesta;
    }

    /**
     * @return the nombreGallera
     */
    public String getNombreGallera() {
        return nombreGallera;
    }

    /**
     * @param nombreGallera the nombreGallera to set
     */
    public void setNombreGallera(String nombreGallera) {
        this.nombreGallera = nombreGallera;
    }

    /**
     * @return the galloRojo
     */
    public Gallo getGalloRojo() {
        return galloRojo;
    }

    /**
     * @param galloRojo the galloRojo to set
     */
    public void setGalloRojo(Gallo galloRojo) {
        this.galloRojo = galloRojo;
    }

    /**
     * @return the galloAzul
     */
    public Gallo getGalloAzul() {
        return galloAzul;
    }

    /**
     * @param galloAzul the galloAzul to set
     */
    public void setGalloAzul(Gallo galloAzul) {
        this.galloAzul = galloAzul;
    }

    /**
     * @return the numeroPeleaId
     */
    public int getNumeroPeleaId() {
        return numeroPelea;
    }

}
