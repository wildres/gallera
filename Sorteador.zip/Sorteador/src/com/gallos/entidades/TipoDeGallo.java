/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.entidades;

/**
 *
 * @author User
 */
public class TipoDeGallo {

    private Integer idTipoDeGallo;
    private String nombre;

    public TipoDeGallo(Integer idTipoDeGallo) {
        this.idTipoDeGallo = idTipoDeGallo;
    }

    public TipoDeGallo() {

    }

    public TipoDeGallo(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the idTipoDeGallo
     */
    public Integer getIdTipoDeGallo() {
        return idTipoDeGallo;
    }

    /**
     * @param idTipoDeGallo the idTipoDeGallo to set
     */
    public void setIdTipoDeGallo(Integer idTipoDeGallo) {
        this.idTipoDeGallo = idTipoDeGallo;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}
