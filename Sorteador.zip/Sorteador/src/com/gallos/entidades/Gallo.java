/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.entidades;

import java.math.BigDecimal;

/**
 *
 * @author User
 */
public class Gallo {

    private Integer idGallo;
    private TipoDeGallo tipo;
    private Plumaje plumaje;
    private Cuerda cuerda;
    private BigDecimal pesoGramos;
    private boolean libre;
    private Integer jaula;
    private Region region;
    private int marca;
    private String anillo;
    private Frente frente;
    private int placa;
    private boolean comodin;
    //Atributo para identificar a cual gallo esta reemplazando el comodin
    private Integer galloOriginal;
    private boolean activo;
    private boolean pava;

    public Gallo(Integer idGallo) {
        this.idGallo = idGallo;
    }

    public Gallo() {
        libre = true;
        activo = true;
    }

    public Gallo(Integer idGallo, Integer idPlumaje, Integer idCuerda) {
        this.idGallo = idGallo;
        this.plumaje = new Plumaje(idPlumaje);
        this.cuerda = new Cuerda(idCuerda);

    }

    /**
     * @return the cuerda
     */
    public Cuerda getCuerda() {
        return cuerda;
    }

    /**
     * @param cuerda the cuerda to set
     */
    public void setCuerda(Cuerda cuerda) {
        this.cuerda = cuerda;
    }

    /**
     * @return the idGallo
     */
    public Integer getIdGallo() {
        return idGallo;
    }

    /**
     * @param idGallo the idGallo to set
     */
    public void setIdGallo(Integer idGallo) {
        this.idGallo = idGallo;
    }

    /**
     * @return the tipo
     */
    public TipoDeGallo getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(TipoDeGallo tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the plumaje
     */
    public Plumaje getPlumaje() {
        return plumaje;
    }

    /**
     * @param plumaje the plumaje to set
     */
    public void setPlumaje(Plumaje plumaje) {
        this.plumaje = plumaje;
    }

    /**
     * @return the libre
     */
    public boolean isLibre() {
        return libre;
    }

    /**
     * @param libre the libre to set
     */
    public void setLibre(boolean libre) {
        this.libre = libre;
    }

    /**
     * @return the jaula
     */
    public Integer getJaula() {
        return jaula;
    }

    /**
     * @param jaula the jaula to set
     */
    public void setJaula(Integer jaula) {
        this.jaula = jaula;
    }

    /**
     * @return the region
     */
    public Region getRegion() {
        return region;
    }

    /**
     * @param region the region to set
     */
    public void setRegion(Region region) {
        this.region = region;
    }

    /**
     * @return the marca
     */
    public Integer getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(int marca) {
        this.marca = marca;
    }

    /**
     * @return the anillo
     */
    public String getAnillo() {
        return anillo;
    }

    /**
     * @param anillo the anillo to set
     */
    public void setAnillo(String anillo) {
        this.anillo = anillo;
    }

    /**
     * @return the frente
     */
    public Frente getFrente() {
        return frente;
    }

    /**
     * @param frente the frente to set
     */
    public void setFrente(Frente frente) {
        this.frente = frente;
    }

    /**
     * @return the placa
     */
    public int getPlaca() {
        return placa;
    }

    /**
     * @param placa the placa to set
     */
    public void setPlaca(int placa) {
        this.placa = placa;
    }

    /**
     * @return the pesoGramos
     */
    public BigDecimal getPesoGramos() {
        return pesoGramos;
    }

    /**
     * @param pesoGramos the pesoGramos to set
     */
    public void setPesoGramos(BigDecimal pesoGramos) {
        this.pesoGramos = pesoGramos;
    }

    /**
     * @return the comodin
     */
    public boolean isComodin() {
        return comodin;
    }

    /**
     * @param comodin the comodin to set
     */
    public void setComodin(boolean comodin) {
        this.comodin = comodin;
    }

    /**
     * @return the galloOriginal
     */
    public Integer getGalloOriginal() {
        return galloOriginal;
    }

    /**
     * @param galloOriginal the galloOriginal to set
     */
    public void setGalloOriginal(Integer galloOriginal) {
        this.galloOriginal = galloOriginal;
    }

    /**
     * @return the activo
     */
    public boolean isActivo() {
        return activo;
    }

    /**
     * @param activo the activo to set
     */
    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    /**
     * @return the pava
     */
    public boolean isPava() {
        return pava;
    }

    public int esPava() {
        return pava?1:0;
    }

    /**
     * @param pava the pava to set
     */
    public void setPava(boolean pava) {
        this.pava = pava;
    }

}
