/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.entidades;

/**
 *
 * @author User
 */
public class GalloPeleaLibre {

    private Integer idGallo;
    private TipoDeGallo tipo;
    private Plumaje plumaje;
    private String cuerda;

    public GalloPeleaLibre(Integer idGallo) {
        this.idGallo = idGallo;
    }

    public GalloPeleaLibre(Integer idGallo, Integer idPlumaje, String cuerda) {
        this.idGallo = idGallo;
        this.plumaje = new Plumaje(idPlumaje);
        this.cuerda = cuerda;

    }

    /**
     * @return the idGallo
     */
    public Integer getIdGallo() {
        return idGallo;
    }

    /**
     * @param idGallo the idGallo to set
     */
    public void setIdGallo(Integer idGallo) {
        this.idGallo = idGallo;
    }

    /**
     * @return the tipo
     */
    public TipoDeGallo getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(TipoDeGallo tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the plumaje
     */
    public Plumaje getPlumaje() {
        return plumaje;
    }

    /**
     * @param plumaje the plumaje to set
     */
    public void setPlumaje(Plumaje plumaje) {
        this.plumaje = plumaje;
    }

    /**
     * @return the cuerda
     */
    public String getCuerda() {
        return cuerda;
    }

    /**
     * @param cuerda the cuerda to set
     */
    public void setCuerda(String cuerda) {
        this.cuerda = cuerda;
    }

}
