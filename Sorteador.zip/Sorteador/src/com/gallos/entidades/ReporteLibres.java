/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.entidades;

/**
 *
 * @author User
 */
public class ReporteLibres {

    private Integer nroPelea;
    private String ganador;
    private Integer minutos;
    private Integer segundos;

    /**
     * @return the minutos
     */
    public Integer getMinutos() {
        return minutos;
    }

    /**
     * @param minutos the minutos to set
     */
    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    /**
     * @return the segundos
     */
    public Integer getSegundos() {
        return segundos;
    }

    /**
     * @param segundos the segundos to set
     */
    public void setSegundos(Integer segundos) {
        this.segundos = segundos;
    }

    /**
     * @return the nroPelea
     */
    public int getNroPelea() {
        return nroPelea;
    }

    /**
     * @param nroPelea the nroPelea to set
     */
    public void setNroPelea(Integer nroPelea) {
        this.nroPelea = nroPelea;
    }

    /**
     * @return the ganador
     */
    public String getGanador() {
        return ganador;
    }

    /**
     * @param ganador the ganador to set
     */
    public void setGanador(String ganador) {
        this.ganador = ganador;
    }

}
