/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.entidades;

/**
 *
 * @author User
 */
public class Plumaje {

    private Integer idPlumaje;
    private String nombre;

    public Plumaje() {

    }

    public Plumaje(Integer idPlumaje, String nombre) {
        this.idPlumaje = idPlumaje;
        this.nombre = nombre;
    }

    public Plumaje(Integer idPlumaje) {
        this.idPlumaje = idPlumaje;
    }

    /**
     * @return the idPlumaje
     */
    public Integer getIdPlumaje() {
        return idPlumaje;
    }

    /**
     * @param idPlumaje the idPlumaje to set
     */
    public void setIdPlumaje(Integer idPlumaje) {
        this.idPlumaje = idPlumaje;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}
