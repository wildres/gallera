/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.entidades;

/**
 *
 * @author User
 */
public class Frente {

    private Integer id;
    private int numeroFrente;
    private String nombre;
    private Cuerda cuerda;
    private Torneo torneo;

    public Frente(Integer id) {
        this.id = id;
    }

    public Frente() {

    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the numeroFrente
     */
    public Integer getNumeroFrente() {
        return numeroFrente;
    }

    /**
     * @param numeroFrente the numeroFrente to set
     */
    public void setNumeroFrente(Integer numeroFrente) {
        this.numeroFrente = numeroFrente;
    }

    /**
     * @return the torneo
     */
    public Torneo getTorneo() {
        return torneo;
    }

    /**
     * @param torneo the torneo to set
     */
    public void setTorneo(Torneo torneo) {
        this.torneo = torneo;
    }

    /**
     * @return the cuerda
     */
    public Cuerda getCuerda() {
        return cuerda;
    }

    /**
     * @param cuerda the cuerda to set
     */
    public void setCuerda(Cuerda cuerda) {
        this.cuerda = cuerda;
    }
}
