/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.entidades;

/**
 *
 * @author User
 */
public class Reporte {

    private int puesto;
    private String nombre;
    private Integer puntos;
    private Integer ganadas;
    private Integer perdidas;
    private Integer empatadas;
    private Integer totalPeleas;
    private Integer minutos;
    private Integer segundos;
    private Integer idCuerda;
    private String nroFrente;

    /**
     * @return the puesto
     */
    public Integer getPuesto() {
        return puesto;
    }

    /**
     * @param puesto the puesto to set
     */
    public void setPuesto(int puesto) {
        this.puesto = puesto;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the puntos
     */
    public Integer getPuntos() {
        return puntos;
    }

    /**
     * @param puntos the puntos to set
     */
    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    /**
     * @return the ganadas
     */
    public Integer getGanadas() {
        return ganadas;
    }

    /**
     * @param ganadas the ganadas to set
     */
    public void setGanadas(int ganadas) {
        this.ganadas = ganadas;
    }

    /**
     * @return the perdidas
     */
    public Integer getPerdidas() {
        return perdidas;
    }

    /**
     * @param perdidas the perdidas to set
     */
    public void setPerdidas(int perdidas) {
        this.perdidas = perdidas;
    }

    /**
     * @return the totalPeleas
     */
    public Integer getTotalPeleas() {
        return totalPeleas;
    }

    /**
     * @param totalPeleas the totalPeleas to set
     */
    public void setTotalPeleas(int totalPeleas) {
        this.totalPeleas = totalPeleas;
    }

    /**
     * @return the minutos
     */
    public Integer getMinutos() {
        return minutos;
    }

    /**
     * @param minutos the minutos to set
     */
    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    /**
     * @return the segundos
     */
    public Integer getSegundos() {
        return segundos;
    }

    /**
     * @param segundos the segundos to set
     */
    public void setSegundos(int segundos) {
        this.segundos = segundos;
    }

    /**
     * @return the idCuerda
     */
    public int getIdCuerda() {
        return idCuerda;
    }

    /**
     * @param idCuerda the idCuerda to set
     */
    public void setIdCuerda(int idCuerda) {
        this.idCuerda = idCuerda;
    }

    /**
     * @return the empatadas
     */
    public Integer getEmpatadas() {
        return empatadas;
    }

    /**
     * @param empatadas the empatadas to set
     */
    public void setEmpatadas(Integer empatadas) {
        this.empatadas = empatadas;
    }

    /**
     * @return the nroFrente
     */
    public String getNroFrente() {
        return nroFrente;
    }

    /**
     * @param nroFrente the nroFrente to set
     */
    public void setNroFrente(String nroFrente) {
        this.nroFrente = nroFrente;
    }

}
