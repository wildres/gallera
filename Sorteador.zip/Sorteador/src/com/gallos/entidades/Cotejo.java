/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.entidades;

import com.gallos.utilidades.EstadoPelea;

/**
 *
 * @author User
 */
public class Cotejo {

    private Integer id;
    private Gallo gallo1;
    private Gallo gallo2;
    private EstadoPelea estado;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the gallo1
     */
    public Gallo getGallo1() {
        return gallo1;
    }

    /**
     * @param gallo1 the gallo1 to set
     */
    public void setGallo1(Gallo gallo1) {
        this.gallo1 = gallo1;
    }

    /**
     * @return the gallo2
     */
    public Gallo getGallo2() {
        return gallo2;
    }

    /**
     * @param gallo2 the gallo2 to set
     */
    public void setGallo2(Gallo gallo2) {
        this.gallo2 = gallo2;
    }

    /**
     * @return the estado
     */
    public EstadoPelea getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(EstadoPelea estado) {
        this.estado = estado;

    }
}
