/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.entidades;

import com.gallos.utilidades.EstadoPelea;

/**
 *
 * @author User
 */
public class PeleaLibre {

    private Integer id;
    private GalloPeleaLibre galloRojo;
    private GalloPeleaLibre galloAzul;
    private Integer ganador;
    private EstadoPelea estadoPelea;
    private String valorApuesta;

    /**
     * @return the galloRojo
     */
    public GalloPeleaLibre getGalloRojo() {
        return galloRojo;
    }

    /**
     * @param galloRojo the galloRojo to set
     */
    public void setGalloRojo(GalloPeleaLibre galloRojo) {
        this.galloRojo = galloRojo;
    }

    /**
     * @return the galloAzul
     */
    public GalloPeleaLibre getGalloAzul() {
        return galloAzul;
    }

    /**
     * @param galloAzul the galloAzul to set
     */
    public void setGalloAzul(GalloPeleaLibre galloAzul) {
        this.galloAzul = galloAzul;
    }

    /**
     * @return the ganador
     */
    public Integer getGanador() {
        return ganador;
    }

    /**
     * @param ganador the ganador to set
     */
    public void setGanador(Integer ganador) {
        this.ganador = ganador;
    }

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the estadoPelea
     */
    public EstadoPelea getEstadoPelea() {
        return estadoPelea;
    }

    /**
     * @param estadoPelea the estadoPelea to set
     */
    public void setEstadoPelea(EstadoPelea estadoPelea) {
        this.estadoPelea = estadoPelea;
    }

    /**
     * @return the valorApuesta
     */
    public String getValorApuesta() {
        return valorApuesta;
    }

    /**
     * @param valorApuesta the valorApuesta to set
     */
    public void setValorApuesta(String valorApuesta) {
        this.valorApuesta = valorApuesta;
    }

}
