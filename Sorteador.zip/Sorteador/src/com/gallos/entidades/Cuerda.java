/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.entidades;

/**
 *
 * @author User
 */
public class Cuerda {

    private Integer idCuerda;
    private String nombre;
    private String responsable;
    private Region region;

    public Cuerda(Integer idCuerda, String nombre) {
        this.idCuerda = idCuerda;
        this.nombre = nombre;
    }

    public Cuerda(Integer idCuerda) {
        this.idCuerda = idCuerda;
    }

    public Cuerda() {
    }

    /**
     * @return the idCuerda
     */
    public Integer getIdCuerda() {
        return idCuerda;
    }

    /**
     * @param idCuerda the idCuerda to set
     */
    public void setIdCuerda(Integer idCuerda) {
        this.idCuerda = idCuerda;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the responsable
     */
    public String getResponsable() {
        return responsable;
    }

    /**
     * @param responsable the responsable to set
     */
    public void setResponsable(String responsable) {
        this.responsable = responsable;
    }

    /**
     * @return the region
     */
    public Region getRegion() {
        return region;
    }

    /**
     * @param region the region to set
     */
    public void setRegion(Region region) {
        this.region = region;
    }

}
