/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.forms;

import com.gallos.entidades.Cuerda;
import com.gallos.entidades.DataVisualizador;
import com.gallos.entidades.Gallo;
import com.gallos.entidades.GalloPeleaLibre;
import com.gallos.entidades.PeleaLibre;
import com.gallos.inicializador.Inicializador;
import com.gallos.modelos.ComboModel;
import com.gallos.modelos.Item;
import com.gallos.modelos.ModeloDatos;
import com.gallos.utilidades.Display;
import com.gallos.utilidades.EstadoPelea;
import com.gallos.utilidades.ParametrosGeneralesEnum;
import com.gallos.utilidades.Utilidades;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class PeleasLibresView extends JFrame {

    /**
     * Creates new form PeleasLibres
     */
    private PeleasLibresView peleasLibresView;
    private Display display;
    
    public PeleasLibresView(java.awt.Frame parent, boolean modal) {
        initComponents();
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        
        cargarComboPlumaje();
        cargarTablaPelasLibres();
        setTitle("Peleas Libres");
        txtValorApuesta.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                
            }
            
            @Override
            public void focusLost(FocusEvent e) {
                BigDecimal validAmount = new BigDecimal(txtValorApuesta.getText().replace(".", ""));
                txtValorApuesta.setText(String.format("%,.0f", validAmount));
            }
        });
        peleasLibresView = this;
        tablaPeleasLibres.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent mouseEvent) {
                if (mouseEvent.getClickCount() == 2 && tablaPeleasLibres.getSelectedRow() != -1) {
                    System.out.println("Pelea a editar " + tablaPeleasLibres.getValueAt(tablaPeleasLibres.getSelectedRow(), 0).toString());
                    PeleaLibre peleaLibre = Inicializador.consultarPeleaLibrePorId(Integer.valueOf(tablaPeleasLibres.getValueAt(tablaPeleasLibres.getSelectedRow(), 0).toString()));
                    DialogEditarPeleaLibre dialogEditarPeleaLibre = new DialogEditarPeleaLibre(peleasLibresView, true, peleaLibre);
                    dialogEditarPeleaLibre.setVisible(true);
                }
            }
        });
    }
    
    private void cargarComboPlumaje() {
        List<String[]> listPlumaje = Inicializador.consultarPlumaje();
        List<Item> listPlumajeCbx = new ArrayList<>();
        for (int i = 0; i < listPlumaje.size(); i++) {
            listPlumajeCbx.add(new Item(Integer.valueOf(listPlumaje.get(i)[0]), listPlumaje.get(i)[1]));
        }
        ComboModel modelPlumaje1 = new ComboModel(listPlumajeCbx);
        cbxColorGallo1.setModel(modelPlumaje1);
        ComboModel modelPlumaje2 = new ComboModel(listPlumajeCbx);
        cbxColorGallo2.setModel(modelPlumaje2);
    }
    
    public void cargarTablaPelasLibres() {
        String[] encabezado = {"N° Pelea", "Color", "Cuerda", "Color", "Cuerda", "Estado", "Ganador", "Valor"};
        List<PeleaLibre> listPeleas = Inicializador.consultarPeleasLibres();
        Object informacion[][] = new Object[listPeleas.size()][encabezado.length];
        for (int j = 0; j < listPeleas.size(); j++) {
            PeleaLibre pelea = listPeleas.get(j);
            informacion[j][0] = pelea.getId();
            informacion[j][1] = pelea.getGalloRojo().getPlumaje().getNombre();
            informacion[j][2] = pelea.getGalloRojo().getCuerda();
            informacion[j][3] = pelea.getGalloAzul().getPlumaje().getNombre();
            informacion[j][4] = pelea.getGalloAzul().getCuerda();
            informacion[j][5] = pelea.getEstadoPelea().getDescripcion();
            if (pelea.getGanador() == -1) {
                informacion[j][6] = "Empate";
            } else if (pelea.getGanador() == 1) {
                informacion[j][6] = "Rojo";
            } else if (pelea.getGanador() == 2) {
                informacion[j][6] = "Azul";
            }
            informacion[j][7] = pelea.getValorApuesta();
        }
        ModeloDatos modelo = new ModeloDatos(informacion, encabezado, false);
        tablaPeleasLibres.setModel(modelo);
    }
    
    public void generarEmpate(Integer peleaId) {
        Inicializador.generarEmpatePeleaLibre(peleaId);
        JOptionPane.showMessageDialog(null, "Empate");
    }
    
    public void generarGanadorPeleaLibre(Integer idPelea, Integer idGalloGanador) {
        Inicializador.generarGanadorPeleaLibre(idPelea, idGalloGanador);
        if (idGalloGanador == 1) {
            JOptionPane.showMessageDialog(null, "Gana Rojo");
        } else {
            JOptionPane.showMessageDialog(null, "Gana Azul");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaPeleasLibres = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanelGallo1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cbxColorGallo1 = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        txtCriadero1 = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        cbxColorGallo2 = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        txtCriadero2 = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        txtValorApuesta = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        btnIniciarPelea = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        btnBorrarDatos = new javax.swing.JButton();
        btnReiniciarEstaPelea = new javax.swing.JButton();

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        tablaPeleasLibres.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "N° Pelea", "Color", "Cuerda", "Color", "Cuerda", "Estado Pelea", "Ganador"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                true, true, false, true, false, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablaPeleasLibres);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 0));
        jLabel1.setText("VS");

        jPanelGallo1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Rojo", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14), new java.awt.Color(255, 102, 0))); // NOI18N
        jPanelGallo1.setMinimumSize(new java.awt.Dimension(302, 122));

        jLabel2.setText("Color:");

        cbxColorGallo1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel3.setText("Criadero");

        javax.swing.GroupLayout jPanelGallo1Layout = new javax.swing.GroupLayout(jPanelGallo1);
        jPanelGallo1.setLayout(jPanelGallo1Layout);
        jPanelGallo1Layout.setHorizontalGroup(
            jPanelGallo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGallo1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanelGallo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanelGallo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbxColorGallo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCriadero1, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanelGallo1Layout.setVerticalGroup(
            jPanelGallo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGallo1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanelGallo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cbxColorGallo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelGallo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtCriadero1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Azul", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14), new java.awt.Color(255, 102, 0))); // NOI18N

        jLabel4.setText("Color:");

        cbxColorGallo2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbxColorGallo2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxColorGallo2ActionPerformed(evt);
            }
        });

        jLabel5.setText("Criadero");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbxColorGallo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCriadero2, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cbxColorGallo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtCriadero2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        txtValorApuesta.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel6.setLabelFor(txtValorApuesta);
        jLabel6.setText("Valor Pelea");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(txtValorApuesta, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtValorApuesta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(44, 44, 44))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanelGallo1, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1)
                        .addGap(9, 9, 9)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(137, 137, 137)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 15, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanelGallo1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(55, 55, 55)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(81, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        btnIniciarPelea.setText("Iniciar Pelea");
        btnIniciarPelea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIniciarPeleaActionPerformed(evt);
            }
        });

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/gallos/forms/guardar.png"))); // NOI18N
        jButton1.setText("Agregar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btnBorrarDatos.setText("Boirrar Todo");
        btnBorrarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarDatosActionPerformed(evt);
            }
        });

        btnReiniciarEstaPelea.setText("Reiniciar Esta Pelea");
        btnReiniciarEstaPelea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReiniciarEstaPeleaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(224, 224, 224)
                        .addComponent(btnReiniciarEstaPelea)
                        .addGap(18, 18, 18)
                        .addComponent(btnIniciarPelea)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnBorrarDatos))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(89, 89, 89)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 603, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(346, 346, 346)
                        .addComponent(jButton1)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnIniciarPelea)
                    .addComponent(btnBorrarDatos)
                    .addComponent(btnReiniciarEstaPelea))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (cbxColorGallo1.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null, "Color es requerido");
            return;
        }
        
        if (txtCriadero1.getText().length() == 0) {
            JOptionPane.showMessageDialog(null, "Cuerda Roja es requerida");
            return;
        }
        
        if (cbxColorGallo2.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null, "Color es requerido");
            return;
        }
        
        if (txtCriadero2.getText().length() == 0) {
            JOptionPane.showMessageDialog(null, "Cuerda Azul es requerida");
            return;
        }
        
        if (txtValorApuesta.getText().length() == 0) {
            JOptionPane.showMessageDialog(null, "Valor apuesta es requerida");
            return;
        }
        GalloPeleaLibre galloRojo = new GalloPeleaLibre(1, ((Item) cbxColorGallo1.getSelectedItem()).getId(), txtCriadero1.getText());
        GalloPeleaLibre galloAzul = new GalloPeleaLibre(2, ((Item) cbxColorGallo2.getSelectedItem()).getId(), txtCriadero2.getText());
        Inicializador.insertarPeleaLibre(galloRojo, galloAzul, txtValorApuesta.getText());
        JOptionPane.showMessageDialog(null, "Registro guardado con éxito");
        cargarTablaPelasLibres();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnIniciarPeleaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIniciarPeleaActionPerformed
        String result = Utilidades.hacerValidacionesGenerales(true);
        if (result != null) {
            JOptionPane.showMessageDialog(null, result, "Error!", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (tablaPeleasLibres.getSelectedRow() >= 0) {            
            PeleaLibre peleaLibre = Inicializador.consultarPeleaLibrePorId(Integer.valueOf(tablaPeleasLibres.getValueAt(tablaPeleasLibres.getSelectedRow(), 0).toString()));
            if (peleaLibre != null) {                
                if (peleaLibre.getEstadoPelea().equals(EstadoPelea.TERMINADA) || peleaLibre.getEstadoPelea().equals(EstadoPelea.PELEANDO)) {
                    JOptionPane.showMessageDialog(null, "Esta pelea no se puede iniciar");
                } else {
                    Gallo galloRojo = new Gallo();
                    galloRojo.setCuerda(new Cuerda(1, peleaLibre.getGalloRojo().getCuerda()));
                    galloRojo.setPlumaje(peleaLibre.getGalloRojo().getPlumaje());
                    galloRojo.setIdGallo(peleaLibre.getGalloRojo().getIdGallo());
                    
                    Gallo galloAzul = new Gallo();
                    galloAzul.setCuerda(new Cuerda(1, peleaLibre.getGalloAzul().getCuerda()));
                    galloAzul.setPlumaje(peleaLibre.getGalloAzul().getPlumaje());
                    galloAzul.setIdGallo(peleaLibre.getGalloAzul().getIdGallo());
                    DataVisualizador dataVisualizador = new DataVisualizador(peleaLibre.getId(),
                            peleaLibre.getValorApuesta(), Inicializador.cache.get(ParametrosGeneralesEnum.NOMBRE_GALLERA.getId()).getValor(),
                            galloRojo, galloAzul);
                    if (display != null) {
                        display.mostrarSiguientePelea(dataVisualizador);
                    } else {
                        display = new Display(dataVisualizador, true, this);
                    }                    
                }
            }
            
        } else {
            JOptionPane.showMessageDialog(null, "No hay registros seleccionados");
        }
    }//GEN-LAST:event_btnIniciarPeleaActionPerformed

    private void cbxColorGallo2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxColorGallo2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxColorGallo2ActionPerformed

    private void btnBorrarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarDatosActionPerformed
        int accion = JOptionPane.showConfirmDialog(null, "Está seguro de borrar todos los datos?: ", "Borrar Datos", JOptionPane.PLAIN_MESSAGE);
        if (accion == 0) {
            Inicializador.borrarPeleasLibres();
            cargarTablaPelasLibres();
        }
    }//GEN-LAST:event_btnBorrarDatosActionPerformed

    private void btnReiniciarEstaPeleaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReiniciarEstaPeleaActionPerformed
        int accion = JOptionPane.showConfirmDialog(null, "Está seguro de reinicar esta pelea?: ", "Reinicar Pelea", JOptionPane.PLAIN_MESSAGE);
        if (accion == 0) {
            Inicializador.actualizarEstadoPeleaLibre(Integer.valueOf(tablaPeleasLibres.getValueAt(tablaPeleasLibres.getSelectedRow(), 0).toString()), EstadoPelea.EN_ESPERA.getId());
            cargarTablaPelasLibres();
        }
    }//GEN-LAST:event_btnReiniciarEstaPeleaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PeleasLibresView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PeleasLibresView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PeleasLibresView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PeleasLibresView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                PeleasLibresView dialog = new PeleasLibresView(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBorrarDatos;
    private javax.swing.JButton btnIniciarPelea;
    private javax.swing.JButton btnReiniciarEstaPelea;
    private javax.swing.JComboBox<String> cbxColorGallo1;
    private javax.swing.JComboBox<String> cbxColorGallo2;
    private javax.swing.JButton jButton1;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanelGallo1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaPeleasLibres;
    private javax.swing.JTextField txtCriadero1;
    private javax.swing.JTextField txtCriadero2;
    private javax.swing.JTextField txtValorApuesta;
    // End of variables declaration//GEN-END:variables
}
