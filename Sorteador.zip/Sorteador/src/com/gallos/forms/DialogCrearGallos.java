/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.forms;

import com.gallos.entidades.Cuerda;
import com.gallos.entidades.Frente;
import com.gallos.entidades.Gallo;
import com.gallos.entidades.ParametroGeneral;
import com.gallos.entidades.Plumaje;
import com.gallos.entidades.Region;
import com.gallos.entidades.TipoDeGallo;
import com.gallos.entidades.Torneo;
import com.gallos.inicializador.Inicializador;
import com.gallos.modelos.ComboModel;
import com.gallos.modelos.Item;
import com.gallos.modelos.ModeloDatos;
import com.gallos.utilidades.ParametrosGeneralesEnum;
import com.gallos.utilidades.TipoGalloEnum;
import com.gallos.utilidades.Utilidades;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.ComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 *
 * @author User
 */
public class DialogCrearGallos extends javax.swing.JDialog {

    private Inicializador inicializador = new Inicializador();
    private DialogCrearGallos dialogCrearGallos;
    private boolean esEdicion = false;
    private Gallo galloTemporal;
    private final Torneo torneo;
    private final boolean esComodin;
    private final Gallo idGalloParaAnular;
    private BuscarGallosPorCuerda viewBuscarGallosPorCuerda;

    /**
     * Creates new form DialogCrearGallos
     */
    public DialogCrearGallos(java.awt.Frame parent, boolean modal, Cuerda cuerda, Torneo torneo, boolean esComodin, Gallo idGalloParaAnular) {
        super(parent, modal);
        initComponents();
        setResizable(false);
        setLocationRelativeTo(null);
        cargarComboTipo(null);
        cargarComboPlumaje(null);
        this.dialogCrearGallos = this;
        this.esComodin = esComodin;
        this.idGalloParaAnular = idGalloParaAnular;
        txtIdCuerda.setEditable(false);
        lblCantidadGallosPorFrente.setText("Cantidad de gallos por frente: "
                + Inicializador.cache.get(ParametrosGeneralesEnum.CANTIDAD_GALLOS_X_FRENTE.getId()).getValor());
        lblNombreTorneo.setText(torneo.getNombre());
        lblTotalGallos.setText("Total gallos para este torneo: " + Inicializador.cantidadDeGallosPorTorneo(Inicializador.consultarTorneoActivo().getId()));
        this.torneo = torneo;
        if (cuerda != null) {
            setCuerda(cuerda);
        } else {
            validarTodasLasCuerdas();
        }
        if (esComodin) {
            btnActualizar.setVisible(false);
            btnBorrar.setVisible(false);
            btnImprimirGallos.setVisible(false);
        }
        acciones();
    }

    private void acciones() {
        txtLibras.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                txtLibras.setText("");
            }

            @Override
            public void focusLost(FocusEvent e) {
                try {
                    if (txtLibras.getText().length() == 3) {
                        if (!txtLibras.getText().contains(".") || !txtLibras.getText().contains(".")) {
                            String parteEntera = txtLibras.getText().substring(0, 1);
                            String parteDecimal = txtLibras.getText().substring(1, txtLibras.getText().length());
                            txtLibras.setText(parteEntera + "," + parteDecimal);
                        }
                    }
                    txtLibras.setText(txtLibras.getText().replace(".", ","));
                    Double.valueOf(txtLibras.getText().replace(",", "."));
                    if (txtLibras.getText().length() >= 4) {
                        if (txtLibras.getText().contains(",")) {
                            String[] array = txtLibras.getText().split(",");
                            if (Integer.valueOf(array[1]) > 15) {
                                Integer nuevoValor = Integer.valueOf(array[0]) + 1;
                                txtLibras.setText(nuevoValor.toString());
                            }
                        } else {
                            txtLibras.setText("0");
                        }
                    }

                    if (txtLibras.getText().length() == 2) {
                        String parteEntera = txtLibras.getText().substring(0, 1);
                        String parteDecimal = txtLibras.getText().substring(1, txtLibras.getText().length());
                        txtLibras.setText(parteEntera + "," + parteDecimal);
                    }
                } catch (NumberFormatException ex) {
                    System.out.println("Error " + ex.getMessage());
                    txtLibras.setText("0");
                }
            }
        });

        tablaGallos.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent mouseEvent) {
                if (mouseEvent.getClickCount() == 2 && tablaGallos.getSelectedRow() != -1) {
                    esEdicion = true;
                    prepararActualizarRegistro();
                }
            }
        });
    }

    private void prepararActualizarRegistro() {
        Integer galloId = Integer.valueOf(tablaGallos.getValueAt(tablaGallos.getSelectedRow(), 0).toString());
        galloTemporal = Inicializador.buscarObjetoGalloPorId(galloId);
        txtAnillo.setText(galloTemporal.getAnillo());
        Item tipo = new Item(galloTemporal.getTipo().getIdTipoDeGallo(), galloTemporal.getTipo().getNombre());
        cargarComboTipo(tipo);
        Item plumaje = new Item(galloTemporal.getPlumaje().getIdPlumaje(), galloTemporal.getPlumaje().getNombre());
        cargarComboPlumaje(plumaje);
        ComboBoxModel<String> modelMarca = cbxMarca.getModel();
        modelMarca.setSelectedItem(galloTemporal.getMarca());
        cbxMarca.setModel(modelMarca);
        txtLibras.setText(Utilidades.darFormatoVisualPeso(galloTemporal.getPesoGramos()).toString());
        checkPava.setSelected(galloTemporal.isPava());
        txtPlaca.setText(String.valueOf(galloTemporal.getPlaca()));
    }

    private void validarTodasLasCuerdas() {
        List<Cuerda> listCuerdas = Inicializador.consultarCuerdas();
        String value = Inicializador.cache.get(ParametrosGeneralesEnum.CANTIDAD_GALLOS_X_FRENTE.getId()).getValor();
        int parametroCantidad = Integer.valueOf(value);
        for (Cuerda cuerda : listCuerdas) {
            Map<Integer, Integer> map = Inicializador.validarGallosPorCuerda(cuerda.getIdCuerda(), torneo.getId());
            for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
                Integer frente = entry.getKey();
                Integer cantidadGallos = entry.getValue();
                int result = frente * parametroCantidad;
                if (result != cantidadGallos) {
                    int requeridos = cantidadGallos - result;
                    if (requeridos < 0) {
                        setCuerda(cuerda);
                        return;
                    }
                }
            }
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtIdCuerda = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        lblNombreCuerda = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        lblNombreTorneo = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        cbxTipo = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cbxPlumaje = new javax.swing.JComboBox<>();
        cbxMarca = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        cbxRegion = new javax.swing.JComboBox<>();
        checkPava = new javax.swing.JCheckBox();
        lblPava = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtAnillo = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtPlaca = new javax.swing.JTextField();
        txtLibras = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaGallos = new javax.swing.JTable();
        btnAgregar = new javax.swing.JButton();
        btnBorrar = new javax.swing.JButton();
        btnImprimirGallos = new javax.swing.JButton();
        lblCantidadGallosPorFrente = new javax.swing.JLabel();
        btnActualizar = new javax.swing.JButton();
        lblTotalGallos = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos Cuerda"));

        jPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setText("Nombre:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setText("Identificador:");

        jPanel4.setBackground(new java.awt.Color(255, 153, 51));

        lblNombreCuerda.setBackground(new java.awt.Color(255, 153, 51));
        lblNombreCuerda.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblNombreCuerda, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(212, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblNombreCuerda, javax.swing.GroupLayout.DEFAULT_SIZE, 22, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(239, 239, 239)
                        .addComponent(jLabel2))
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtIdCuerda, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIdCuerda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/gallos/forms/buscar.png"))); // NOI18N
        jButton1.setText("Buscar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel10.setText("Nombre del Torneo:");

        lblNombreTorneo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblNombreTorneo.setText(" ");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(198, 198, 198)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblNombreTorneo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(lblNombreTorneo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos del gallo"));

        cbxTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbxTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                actionCambioTipo(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setText("Tipo:");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setText("Plumaje:");

        cbxPlumaje.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbxMarca.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "  ", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        cbxMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxMarcaActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setText("Marca:");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setText("Región");

        cbxRegion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbxRegion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxRegionActionPerformed(evt);
            }
        });

        lblPava.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblPava.setText("Pava:");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(32, 32, 32)
                        .addComponent(cbxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(lblPava))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(checkPava)
                            .addComponent(cbxPlumaje, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(47, 47, 47)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbxRegion, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbxMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(cbxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(11, 11, 11))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(cbxMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(cbxPlumaje, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(cbxRegion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(checkPava)
                    .addComponent(lblPava))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder("Peso"));

        jLabel7.setText("Peso:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setText("Anillo");

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel11.setText("Placa");

        txtPlaca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPlacaActionPerformed(evt);
            }
        });

        txtLibras.setText("     ");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(18, 18, 18)
                                .addComponent(txtAnillo, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addGap(19, 19, 19)
                                .addComponent(txtPlaca)))
                        .addContainerGap())
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(txtLibras, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtLibras, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtAnillo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txtPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tablaGallos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Cuerda", "Anillo", "Tipo", "Plumaje", "Peso", "Libras", "Región", "Jaula"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablaGallos);
        if (tablaGallos.getColumnModel().getColumnCount() > 0) {
            tablaGallos.getColumnModel().getColumn(7).setResizable(false);
        }

        btnAgregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/gallos/forms/mas.png"))); // NOI18N
        btnAgregar.setText("Agregar Gallo");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnBorrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/gallos/forms/borrar.png"))); // NOI18N
        btnBorrar.setText("Borrar Gallo");
        btnBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borrarGallo(evt);
            }
        });

        btnImprimirGallos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/gallos/forms/impresora16px.png"))); // NOI18N
        btnImprimirGallos.setText("Imprimir Gallos");
        btnImprimirGallos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimirGallosActionPerformed(evt);
            }
        });

        lblCantidadGallosPorFrente.setText("Cantidad de gallos por frente: ");

        btnActualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/gallos/forms/refrescar.png"))); // NOI18N
        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        lblTotalGallos.setText("Total gallos para este torneo: ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(96, 96, 96)
                        .addComponent(btnBorrar)
                        .addGap(32, 32, 32)
                        .addComponent(btnActualizar)
                        .addGap(18, 18, 18)
                        .addComponent(btnAgregar))
                    .addComponent(lblCantidadGallosPorFrente))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(btnImprimirGallos))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblTotalGallos)
                        .addGap(27, 27, 27))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jPanel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 689, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBorrar)
                    .addComponent(btnActualizar)
                    .addComponent(btnAgregar)
                    .addComponent(btnImprimirGallos))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTotalGallos)
                    .addComponent(lblCantidadGallosPorFrente)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cargarComboPlumaje(Item selected) {
        List<String[]> listPlumaje = Inicializador.consultarPlumaje();
        List<Item> listPlumajeCbx = new ArrayList<>();
        for (int i = 0; i < listPlumaje.size(); i++) {
            listPlumajeCbx.add(new Item(Integer.valueOf(listPlumaje.get(i)[0]), listPlumaje.get(i)[1]));
        }
        ComboModel modelPlumaje = new ComboModel(listPlumajeCbx);
        if (selected != null) {
            modelPlumaje.setSelectedItem(selected);
        }

        cbxPlumaje.setModel(modelPlumaje);
    }

    private void cargarComboTipo(Item selected) {
        List<String[]> listTipos = inicializador.consultarTipoDeGallos();
        List<Item> listCbx = new ArrayList<>();
        for (int i = 0; i < listTipos.size(); i++) {
            listCbx.add(new Item(Integer.valueOf(listTipos.get(i)[0]), listTipos.get(i)[1]));
        }
        ComboModel model = new ComboModel(listCbx);
        if (selected != null) {
            model.setSelectedItem(selected);
        }
        cbxTipo.setModel(model);
    }

    private void cargarComboRegiones(Item regionSelected) {
        List<Region> listRegiones = Inicializador.consultarRegiones();
        List<Item> listRegionesCbx = new ArrayList<>();
        for (int i = 0; i < listRegiones.size(); i++) {
            Region region = listRegiones.get(i);
            listRegionesCbx.add(new Item(region.getId(), region.getNombre()));
        }
        ComboModel modelRegion = new ComboModel(listRegionesCbx);
        modelRegion.setSelectedItem(regionSelected);
        cbxRegion.setModel(modelRegion);
    }

    private void cargarTablaGallos(Integer idCuerda) {
        String[] encabezado = {"Id", "Cuerda", "Anillo", "Tipo", "Plumaje", "Peso", "Frente", "Región", "Jaula"};
        List<Gallo> listGallos = Inicializador.consultarGallosPorCuerda(idCuerda, torneo.getId());
        Object informacion[][] = new Object[listGallos.size()][encabezado.length];
        for (int j = 0; j < listGallos.size(); j++) {
            Gallo gallo = listGallos.get(j);
            informacion[j][0] = gallo.getIdGallo().toString();
            informacion[j][1] = gallo.getCuerda().getNombre();
            informacion[j][2] = gallo.getAnillo();
            informacion[j][3] = gallo.getTipo().getNombre();
            informacion[j][4] = gallo.getPlumaje().getNombre();
            informacion[j][5] = Utilidades.darFormatoVisualPeso(gallo.getPesoGramos());
            informacion[j][6] = gallo.getFrente().getNumeroFrente();
            informacion[j][7] = gallo.getRegion().getNombre();
            informacion[j][8] = gallo.getJaula().toString();
        }
        ModeloDatos modelo = new ModeloDatos(informacion, encabezado, false);
        tablaGallos.setModel(modelo);
        lblTotalGallos.setText("Total gallos para este torneo: " + Inicializador.cantidadDeGallosPorTorneo(torneo.getId()));
    }

    public void setCuerda(Cuerda cuerda) {
        txtIdCuerda.setText(cuerda.getIdCuerda().toString());
        lblNombreCuerda.setText(cuerda.getNombre().toUpperCase());
        if (!esComodin) {
            cargarTablaGallos(Integer.valueOf(txtIdCuerda.getText()));
        }
        limpiarCampos();
        Item region = new Item(cuerda.getRegion().getId(), cuerda.getRegion().getNombre());
        cargarComboRegiones(region);
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String value = Inicializador.cache.get(ParametrosGeneralesEnum.CANTIDAD_GALLOS_X_FRENTE.getId()).getValor();
        int parametroCantidad = Integer.valueOf(value);
        if (txtIdCuerda.getText() != null && !txtIdCuerda.getText().isEmpty()) {
            Map<Integer, Integer> map = Inicializador.validarGallosPorCuerda(Integer.valueOf(txtIdCuerda.getText()), torneo.getId());
            for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
                Integer frente = entry.getKey();
                Integer cantidadGallos = entry.getValue();
                int result = frente * parametroCantidad;
                if (result != cantidadGallos) {
                    int requeridos = cantidadGallos - result;
                    if (requeridos < 0) {
                        requeridos = requeridos * -1;
                    }
                    StringBuilder message = new StringBuilder();
                    message.append("Al frente [").append(frente).append("]");
                    message.append(" le hacen falta [").append(requeridos).append("]");
                    message.append(" gallos");
                    JOptionPane.showMessageDialog(null, message.toString(),
                            "WARNING_MESSAGE", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

        }

        DialogBuscarCuerdas dialogBuscarCuerdas = new DialogBuscarCuerdas(null, true, dialogCrearGallos);
        dialogBuscarCuerdas.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        try {
            if (!esEdicion) {
                if (txtIdCuerda.getText() == null || (txtIdCuerda.getText() != null
                        && txtIdCuerda.getText().trim().isEmpty())) {
                    JOptionPane.showMessageDialog(null, "No hay ninguna cuerda seleccionada");
                    return;
                }

                if (txtAnillo.getText() == null || (txtAnillo.getText() != null
                        && txtAnillo.getText().trim().isEmpty())) {
                    JOptionPane.showMessageDialog(null, "Digite el número del anillo");
                    return;
                }

                if (cbxTipo.getSelectedItem() == null) {
                    JOptionPane.showMessageDialog(null, "No hay tipo seleccionado");
                    return;
                }

                if (cbxPlumaje.getSelectedItem() == null) {
                    JOptionPane.showMessageDialog(null, "No hay plumaje seleccionado");
                    return;
                }

                Item tipo = (Item) cbxTipo.getSelectedItem();
                int marca = 0;
                int placa = 0;
                if (!tipo.getId().equals(TipoGalloEnum.GALLO.getId())) {
                    if (cbxMarca.getSelectedItem() == null || (cbxMarca.getSelectedItem() != null && cbxMarca.getSelectedItem().toString().trim().isEmpty())) {
                        JOptionPane.showMessageDialog(null, "No hay marca seleccionada");
                        return;
                    } else {
                        marca = Integer.valueOf(cbxMarca.getSelectedItem().toString());
                    }

                    if (!txtPlaca.getText().trim().isEmpty()) {
                        Integer.valueOf(txtAnillo.getText());
                        if (Double.valueOf(txtLibras.getText().replace(",", ".")) <= 0) {
                            throw new Exception("Peso no valido");
                        }
                    }

                    if (txtPlaca.getText() == null || (txtPlaca.getText() != null
                            && txtPlaca.getText().trim().isEmpty())) {
                        JOptionPane.showMessageDialog(null, "Digite el número de la placa");
                        return;
                    } else {
                        placa = Integer.valueOf(txtPlaca.getText());
                    }
                }
                if (cbxRegion.getSelectedItem() == null || (cbxRegion.getSelectedItem() != null && cbxRegion.getSelectedItem().toString().trim().isEmpty())) {
                    JOptionPane.showMessageDialog(null, "No hay región seleccionada");
                    return;
                }

                if ((txtLibras.getText() == null) || (txtLibras.getText() != null && txtLibras.getText().isEmpty())) {
                    JOptionPane.showMessageDialog(null, "No hay peso establecido");
                    return;
                }
                Integer.valueOf(txtAnillo.getText());
                if (Double.valueOf(txtLibras.getText().replace(",", ".")) <= 0) {
                    throw new Exception("Peso no valido");
                }

                boolean existeAnillo = inicializador.existeAnillo(txtAnillo.getText());
                if (existeAnillo) {
                    JOptionPane.showMessageDialog(null, "El número de anillo ya existe");
                    return;
                }

                ParametroGeneral parametro = Inicializador.cache.get(ParametrosGeneralesEnum.CANTIDAD_GALLOS_X_FRENTE.getId());
                Frente frenteActual = null;
                if (!esComodin) {
                    frenteActual = inicializador.consultarNumeroDeFrentePorCuerda(Integer.valueOf(txtIdCuerda.getText()), torneo.getId());
                    int cantidadGallosPorFrente = Inicializador.consultarGallosPorFrente(frenteActual.getNumeroFrente(), Integer.valueOf(txtIdCuerda.getText()), Inicializador.consultarTorneoActivo().getId()).size();
                    if (frenteActual.getNumeroFrente() == 0 || (cantidadGallosPorFrente + 1) > Integer.valueOf(parametro.getValor())) {
                        frenteActual.setNumeroFrente(frenteActual.getNumeroFrente() + 1);
                        JTextField txtNombreFrente = new JTextField();
                        txtNombreFrente.setText(lblNombreCuerda.getText() + " " + frenteActual.getNumeroFrente());
                        String labelField = "Ingrese el nombre para el frente número [" + (frenteActual.getNumeroFrente()) + "]";
                        Object[] fields = {labelField, txtNombreFrente};
                        int opcion = JOptionPane.showConfirmDialog(null, fields, "Frente", JOptionPane.PLAIN_MESSAGE);
                        if (opcion == -1) {
                            return;
                        }
                        while (txtNombreFrente.getText().trim().length() == 0) {
                            JOptionPane.showConfirmDialog(null, fields, "Frente", JOptionPane.PLAIN_MESSAGE);
                        }
                        frenteActual.setNombre(txtNombreFrente.getText());
                        frenteActual.setCuerda(new Cuerda(Integer.valueOf(txtIdCuerda.getText())));
                        frenteActual.setTorneo(new Torneo(torneo.getId()));
                        inicializador.crearFrente(frenteActual);
                    }
                }
                Item plumaje = (Item) cbxPlumaje.getSelectedItem();
                Item region = (Item) cbxRegion.getSelectedItem();
                Gallo gallo = new Gallo();
                gallo.setCuerda(new Cuerda(Integer.valueOf(txtIdCuerda.getText())));
                gallo.setAnillo(txtAnillo.getText());
                gallo.setTipo(new TipoDeGallo(tipo.getId()));
                gallo.setPlumaje(new Plumaje(plumaje.getId()));
                gallo.setPesoGramos(Utilidades.convertirPeso(txtLibras.getText()));
                gallo.setMarca(marca);
                gallo.setRegion(new Region(region.getId()));
                gallo.setFrente(frenteActual);
                gallo.setPlaca(placa);
                gallo.setComodin(esComodin);
                gallo.setPava(checkPava.isSelected());
                if (idGalloParaAnular != null) {
                    gallo.setGalloOriginal(idGalloParaAnular.getIdGallo());
                }
                inicializador.agregarGallo(gallo);
                if (esComodin) {
                    viewBuscarGallosPorCuerda.terminarRegistro(this, idGalloParaAnular);
                }
                cargarTablaGallos(Integer.valueOf(txtIdCuerda.getText()));
                limpiarCampos();
            } else {
                limpiarCampos();
                esEdicion = false;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Formato no valido: " + ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void limpiarCampos() {
        txtAnillo.setText("");
        cbxTipo.setSelectedItem(null);
        cbxPlumaje.setSelectedItem(null);
        cbxMarca.setSelectedItem(null);
        txtLibras.setText("");
        galloTemporal = null;
        checkPava.setSelected(false);
        txtPlaca.setText("");
        JPanel temp = (JPanel) this.getContentPane();
        SwingUtilities.updateComponentTreeUI(temp);

    }

    private void borrarGallo(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borrarGallo

        if (txtIdCuerda.getText() == null || (txtIdCuerda.getText() != null
                && txtIdCuerda.getText().trim().isEmpty())) {
            JOptionPane.showMessageDialog(null, "No hay ninguna cuerda seleccionada");
        } else if (tablaGallos.getSelectedRows().length == 0) {
            JOptionPane.showMessageDialog(null, "No hay ningún gallo seleccionado");
        } else {
            int[] rows = tablaGallos.getSelectedRows();
            for (int row : rows) {
                System.out.println("Fila " + row);
                int idGallo = Integer.valueOf(tablaGallos.getValueAt(row, 0).toString());
                Gallo gallo = Inicializador.buscarObjetoGalloPorId(idGallo);
                int count = Inicializador.consultarGallosPorFrente(gallo.getFrente().getNumeroFrente(), Integer.valueOf(txtIdCuerda.getText()), Inicializador.consultarTorneoActivo().getId()).size();
                if (count == 0) {
                    Inicializador.borrarFrente(gallo.getFrente().getId());
                }
                System.out.println("Borrando gallo " + gallo.getIdGallo());
                inicializador.borrarGallo(gallo.getIdGallo());
            }
            cargarTablaGallos(Integer.valueOf(txtIdCuerda.getText()));
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_borrarGallo

    private void cbxMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxMarcaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxMarcaActionPerformed

    private void actionCambioTipo(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actionCambioTipo

        Item item = (Item) cbxTipo.getSelectedItem();
        if (item != null) {
            if (item.getId().equals(1)) {
                cbxMarca.setEnabled(false);
                cbxMarca.setSelectedItem(null);
                txtPlaca.setEnabled(false);
                txtPlaca.setText("");
            } else {
                cbxMarca.setEnabled(true);
                txtPlaca.setEnabled(true);
            }
        }
    }//GEN-LAST:event_actionCambioTipo

    private void btnImprimirGallosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimirGallosActionPerformed
        if (txtIdCuerda.getText() == null || (txtIdCuerda.getText() != null
                && txtIdCuerda.getText().trim().isEmpty())) {
            JOptionPane.showMessageDialog(null, "No hay ninguna cuerda seleccionada");
            return;
        }

        Cuerda cuerda = Inicializador.consultarCuerdaPorId(Integer.valueOf(txtIdCuerda.getText()));
        List<Cuerda> list = new ArrayList<>();
        list.add(cuerda);
        System.out.println("idCurerda " + cuerda.getIdCuerda() + " nombre " + cuerda.getNombre());
        Utilidades.imprimirCuerdas(list, cuerda.getNombre(), false);
    }//GEN-LAST:event_btnImprimirGallosActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        try {
            if (tablaGallos.getSelectedRow() >= 0) {
                if (txtIdCuerda.getText() == null || (txtIdCuerda.getText() != null
                        && txtIdCuerda.getText().trim().isEmpty())) {
                    JOptionPane.showMessageDialog(null, "No hay ninguna cuerda seleccionada");
                    return;
                }

                if (txtAnillo.getText() == null || (txtAnillo.getText() != null
                        && txtAnillo.getText().trim().isEmpty())) {
                    JOptionPane.showMessageDialog(null, "Digite el número del anillo");
                    return;
                }

                if (cbxTipo.getSelectedItem() == null) {
                    JOptionPane.showMessageDialog(null, "No hay tipo seleccionado");
                    return;
                }

                if (cbxPlumaje.getSelectedItem() == null) {
                    JOptionPane.showMessageDialog(null, "No hay plumaje seleccionado");
                    return;
                }

                Item tipo = (Item) cbxTipo.getSelectedItem();
                String marca = null;
                if (!tipo.getId().equals(TipoGalloEnum.GALLO.getId())) {
                    if (cbxMarca.getSelectedItem() == null || (cbxMarca.getSelectedItem() != null && cbxMarca.getSelectedItem().toString().trim().isEmpty())) {
                        JOptionPane.showMessageDialog(null, "No hay marca seleccionada");
                        return;
                    } else {
                        marca = cbxMarca.getSelectedItem().toString();
                    }

                }
                if (cbxRegion.getSelectedItem() == null || (cbxRegion.getSelectedItem() != null && cbxRegion.getSelectedItem().toString().trim().isEmpty())) {
                    JOptionPane.showMessageDialog(null, "No hay región seleccionada");
                    return;
                }

                if ((txtLibras.getText() == null) || (txtLibras.getText() != null && txtLibras.getText().isEmpty())) {
                    JOptionPane.showMessageDialog(null, "No hay peso establecido");
                    return;
                }
                Integer.valueOf(txtAnillo.getText());
                if (Double.valueOf(txtLibras.getText().replace(",", ".")) <= 0) {
                    throw new Exception("Peso no valido");
                }

                if (!(galloTemporal != null && galloTemporal.getAnillo().equalsIgnoreCase(txtAnillo.getText()))) {
                    boolean existeAnillo = inicializador.existeAnillo(txtAnillo.getText());
                    if (existeAnillo) {
                        JOptionPane.showMessageDialog(null, "El número de anillo ya existe");
                        return;
                    }
                }

                Item plumaje = (Item) cbxPlumaje.getSelectedItem();
                Item region = (Item) cbxRegion.getSelectedItem();
                Object[] data = {
                    txtAnillo.getText(),
                    tipo.getId().toString(),
                    plumaje.getId().toString(),
                    marca,
                    region.getId(),
                    checkPava.isSelected() ? 1 : 0,
                    Utilidades.convertirPeso(txtLibras.getText())
                };
                inicializador.actualizarGallo(data, galloTemporal.getIdGallo());
                cargarTablaGallos(Integer.valueOf(txtIdCuerda.getText()));
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(null, "No hay registros seleccionados");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Formato no valido: " + ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void txtPlacaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPlacaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPlacaActionPerformed

    private void cbxRegionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxRegionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxRegionActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnImprimirGallos;
    private javax.swing.JComboBox<String> cbxMarca;
    private javax.swing.JComboBox<String> cbxPlumaje;
    private javax.swing.JComboBox<String> cbxRegion;
    private javax.swing.JComboBox<String> cbxTipo;
    private javax.swing.JCheckBox checkPava;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCantidadGallosPorFrente;
    private javax.swing.JLabel lblNombreCuerda;
    private javax.swing.JLabel lblNombreTorneo;
    private javax.swing.JLabel lblPava;
    private javax.swing.JLabel lblTotalGallos;
    private javax.swing.JTable tablaGallos;
    private javax.swing.JTextField txtAnillo;
    private javax.swing.JTextField txtIdCuerda;
    private javax.swing.JTextField txtLibras;
    private javax.swing.JTextField txtPlaca;
    // End of variables declaration//GEN-END:variables

    /**
     * @return the viewBuscarGallosPorCuerda
     */
    public BuscarGallosPorCuerda getViewBuscarGallosPorCuerda() {
        return viewBuscarGallosPorCuerda;
    }

    /**
     * @param viewBuscarGallosPorCuerda the viewBuscarGallosPorCuerda to set
     */
    public void setViewBuscarGallosPorCuerda(BuscarGallosPorCuerda viewBuscarGallosPorCuerda) {
        this.viewBuscarGallosPorCuerda = viewBuscarGallosPorCuerda;
    }
}
