/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gallos.forms;

import com.gallos.entidades.Cotejo;
import com.gallos.entidades.Cuerda;
import com.gallos.entidades.Gallo;
import com.gallos.entidades.Region;
import com.gallos.inicializador.Inicializador;
import com.gallos.modelos.ModeloDatos;
import com.gallos.utilidades.EstadoPelea;
import com.gallos.utilidades.Tipo_Generacion;
import com.gallos.utilidades.Utilidades;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class DialogCotejoGallos extends javax.swing.JDialog {

    /**
     * Creates new form DialogCotejoGallos //
     */
//    private Inicializador inicializador = new Inicializador();
    private Integer idGalloManual1 = null;
    private Integer idGalloManual2 = null;

    private Map<Cuerda, Cuerda> mapExepcionesCuerdas = Inicializador.consultarExcepcionesPorCuerda();
    private Map<Region, Region> mapExepcionesRegiones = Inicializador.consultarExcepcionesPorRegion();

    public DialogCotejoGallos(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setResizable(false);
        setLocationRelativeTo(null);
        txtGallosCotejar.setEditable(false);
        cargarTablaGallosLibres();
        cargarTablaPeleasPactadas();
        txtGramosTolerancia.setText("0");
        cargarCotejos();
    }

    private void cargarTablaGallosLibres() {
        String[] encabezado = {"Id", "Tipo", "Cuerda", "Peso", "Marca"};
        if (Inicializador.consultarTorneoActivo() != null) {
            List<Gallo> listTipoDeGallos = Inicializador.gallosLibres(Inicializador.consultarTorneoActivo().getId());
            Object informacion[][] = new Object[listTipoDeGallos.size()][encabezado.length];
            boolean isPollo = true;
            for (int j = 0; j < listTipoDeGallos.size(); j++) {
                Gallo gallo = listTipoDeGallos.get(j);
                if (gallo.isComodin()) {
                    gallo.getCuerda().setNombre(gallo.getCuerda().getNombre() + " -[COMODIN]-");
                }
                informacion[j][0] = gallo.getIdGallo().toString();
                informacion[j][1] = gallo.getTipo().getNombre();
                informacion[j][2] = gallo.getCuerda().getNombre();
                informacion[j][3] = Utilidades.darFormatoVisualPeso(gallo.getPesoGramos());
                informacion[j][4] = gallo.getMarca().toString();
                if (isPollo && gallo.getTipo().getIdTipoDeGallo() == 2) {
                    isPollo = false;
                }
            }
            ModeloDatos modelo = new ModeloDatos(informacion, encabezado, false);
            tablaGallosLibres.setModel(modelo);
            lblGallosLibres.setText("Registros Encotrados: " + informacion.length);
            tablaGallosLibres.getColumnModel().getColumn(0).setMinWidth(30);
            tablaGallosLibres.getColumnModel().getColumn(0).setMaxWidth(30);
            tablaGallosLibres.getColumnModel().getColumn(0).setWidth(30);

            tablaGallosLibres.getColumnModel().getColumn(1).setMinWidth(60);
            tablaGallosLibres.getColumnModel().getColumn(1).setMaxWidth(60);
            tablaGallosLibres.getColumnModel().getColumn(1).setWidth(60);

            tablaGallosLibres.getColumnModel().getColumn(3).setMinWidth(50);
            tablaGallosLibres.getColumnModel().getColumn(3).setMaxWidth(50);
            tablaGallosLibres.getColumnModel().getColumn(3).setWidth(50);
            if (isPollo) {
                tablaGallosLibres.getColumnModel().getColumn(4).setMinWidth(0);
                tablaGallosLibres.getColumnModel().getColumn(4).setMaxWidth(0);
                tablaGallosLibres.getColumnModel().getColumn(4).setWidth(0);
            } else {
                tablaGallosLibres.getColumnModel().getColumn(4).setMinWidth(5);
                tablaGallosLibres.getColumnModel().getColumn(4).setMaxWidth(5);
                tablaGallosLibres.getColumnModel().getColumn(4).setWidth(5);
            }
        } else {
            Utilidades.mostrarMensaje("Torneo: " + "No hay torneo activo", JOptionPane.INFORMATION_MESSAGE);
        }

    }

    private void cargarTablaPeleasPactadas() {
        String[] encabezado = {"Cotejo", "Tipo", "Cuerda", "Anillo", "De peso", "Marca", "Región",
            "Vs Tipo", "Cuerda", "Anillo", "Gallo", "De peso", "Marca", "Región"};
        List<Cotejo> listCotejos = Inicializador.consultarPeleasPactadas(Inicializador.consultarTorneoActivo().getId());
        Object informacion[][] = new Object[listCotejos.size()][encabezado.length];
        for (int j = 0; j < listCotejos.size(); j++) {
            Cotejo cotejo = listCotejos.get(j);
            informacion[j][0] = cotejo.getId().toString();
            informacion[j][1] = cotejo.getGallo1().getTipo().getNombre();
            informacion[j][2] = cotejo.getGallo1().getCuerda().getNombre();
            informacion[j][3] = cotejo.getGallo1().getAnillo();
            informacion[j][4] = Utilidades.darFormatoVisualPeso(cotejo.getGallo1().getPesoGramos());
            informacion[j][5] = cotejo.getGallo1().getMarca().toString();
            informacion[j][6] = cotejo.getGallo1().getRegion().getNombre();
            informacion[j][7] = cotejo.getGallo2().getTipo().getNombre();
            informacion[j][8] = cotejo.getGallo2().getCuerda().getNombre();
            informacion[j][9] = cotejo.getGallo2().getAnillo();
            informacion[j][10] = cotejo.getGallo2().getIdGallo().toString();
            informacion[j][11] = Utilidades.darFormatoVisualPeso(cotejo.getGallo2().getPesoGramos());
            informacion[j][12] = cotejo.getGallo2().getMarca().toString();
            informacion[j][13] = cotejo.getGallo2().getRegion().getNombre();
        }
        ModeloDatos modelo = new ModeloDatos(informacion, encabezado, false);
        tablaPeleasPactadas.setModel(modelo);
        lblPeleasPactadas.setText("Número de peleas pactadas: " + informacion.length);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jInternalFrame1 = new javax.swing.JInternalFrame();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        lblTolerancia = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        txtGramosTolerancia = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        txtGallosCotejar = new javax.swing.JTextField();
        btnCotejar = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        lblCuerda2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaGallo2 = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        lblCuerda1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaGallo1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablaCotejos = new javax.swing.JTable();
        btnPactarPeleas = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        lblPeleasEncontradas = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tablaGallosLibres = new javax.swing.JTable();
        jPanel10 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        lblCuerdaDetalle = new javax.swing.JLabel();
        lblDescripcion = new javax.swing.JLabel();
        lblTipoDetalle = new javax.swing.JLabel();
        lblPlumaje = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        rBtnGallo1 = new javax.swing.JRadioButton();
        rBtnGallo2 = new javax.swing.JRadioButton();
        jLabel13 = new javax.swing.JLabel();
        btnCotejoManual = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        lblPava = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        lblPesoDetalle = new javax.swing.JLabel();
        lblGallosLibres = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tablaPeleasPactadas = new javax.swing.JTable();
        lblPeleasPactadas = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jInternalFrame1.setTitle("Generar Cotejos");
        jInternalFrame1.setVisible(true);

        jPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lblTolerancia.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblTolerancia.setText("<html>Tolerancia:<p> en el peso<html>");

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jLabel1.setText("<html>Gallos a<p>  cotejar:<html>");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(69, Short.MAX_VALUE)
                .addComponent(txtGramosTolerancia, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(txtGallosCotejar, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtGallosCotejar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtGramosTolerancia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 6, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblTolerancia)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblTolerancia)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnCotejar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/gallos/forms/libro.png"))); // NOI18N
        btnCotejar.setText("Cotejar");
        btnCotejar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCotejarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnCotejar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnCotejar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel4.setBackground(new java.awt.Color(0, 0, 0));

        lblCuerda2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblCuerda2.setForeground(new java.awt.Color(255, 204, 51));
        lblCuerda2.setText("                        ");

        tablaGallo2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null}
            },
            new String [] {
                "TIPO", "ID", "ANILLO", "PLUMAJE", "PESO"
            }
        ));
        jScrollPane1.setViewportView(tablaGallo2);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCuerda2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 491, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(lblCuerda2, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(0, 0, 0));

        lblCuerda1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblCuerda1.setForeground(new java.awt.Color(255, 204, 51));
        lblCuerda1.setText("    ");

        tablaGallo1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null}
            },
            new String [] {
                "TIPO", "ID", "ANILLO", "PLUMAJE", "PESO"
            }
        ));
        tablaGallo1.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                tablaGallo1PropertyChange(evt);
            }
        });
        tablaGallo1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tablaGallo1KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tablaGallo1KeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tablaGallo1KeyTyped(evt);
            }
        });
        tablaGallo1.addVetoableChangeListener(new java.beans.VetoableChangeListener() {
            public void vetoableChange(java.beans.PropertyChangeEvent evt)throws java.beans.PropertyVetoException {
                tablaGallo1VetoableChange(evt);
            }
        });
        jScrollPane2.setViewportView(tablaGallo1);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 490, Short.MAX_VALUE)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCuerda1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(lblCuerda1, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jLabel4.setBackground(new java.awt.Color(204, 0, 0));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 0, 0));
        jLabel4.setText("VS");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(214, 214, 214)
                .addComponent(jLabel4)
                .addContainerGap(253, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel4))
        );

        jTabbedPane1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        tablaCotejos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Cotejo", "Gallo", "VS Gallo", "Estado"
            }
        ));
        tablaCotejos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaCotejosMouseClicked(evt);
            }
        });
        tablaCotejos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tablaCotejosKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tablaCotejosKeyReleased(evt);
            }
        });
        jScrollPane3.setViewportView(tablaCotejos);

        btnPactarPeleas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/gallos/forms/liberar.png"))); // NOI18N
        btnPactarPeleas.setText("Pactar Todo");
        btnPactarPeleas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPactarPeleasActionPerformed(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/gallos/forms/rompecabezas.png"))); // NOI18N
        jButton3.setText("Liberar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/gallos/forms/impresora.png"))); // NOI18N
        jButton4.setText("Imprimir");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        lblPeleasEncontradas.setText("Registros Encotrados:");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(lblPeleasEncontradas)
                        .addContainerGap(409, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnPactarPeleas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(btnPactarPeleas)
                        .addGap(40, 40, 40)
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblPeleasEncontradas)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Cotejos", jPanel6);

        tablaGallosLibres.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "TIPO", "CUERDA", "PESO", "MARCA"
            }
        ));
        tablaGallosLibres.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaGallosLibresMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tablaGallosLibres);

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder("Detalles"));

        jPanel11.setBackground(new java.awt.Color(0, 0, 0));

        jLabel5.setForeground(new java.awt.Color(255, 153, 0));

        lblCuerdaDetalle.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblCuerdaDetalle.setForeground(new java.awt.Color(255, 102, 0));
        lblCuerdaDetalle.setText("   ");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblCuerdaDetalle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(lblCuerdaDetalle)
        );

        lblDescripcion.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblDescripcion.setText("   ");

        lblTipoDetalle.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblTipoDetalle.setText("  ");

        lblPlumaje.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblPlumaje.setText("         ");

        jLabel10.setBackground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("PESO:");

        jPanel14.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        rBtnGallo1.setText("Gallo");
        rBtnGallo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rBtnGallo1ActionPerformed(evt);
            }
        });

        rBtnGallo2.setText("Gallo");
        rBtnGallo2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rBtnGallo2ActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 51, 0));
        jLabel13.setText("VS");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addComponent(rBtnGallo1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(rBtnGallo2)
                .addContainerGap())
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rBtnGallo1)
                    .addComponent(rBtnGallo2)
                    .addComponent(jLabel13))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnCotejoManual.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/gallos/forms/animal.png"))); // NOI18N
        btnCotejoManual.setText("Manual");
        btnCotejoManual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCotejoManualActionPerformed(evt);
            }
        });

        jLabel7.setText("Desc:");

        jLabel8.setText("Tipo:");

        jLabel9.setText("Plumaje:");

        lblPava.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblPava.setText("         ");

        jLabel12.setText("Pava:");

        lblPesoDetalle.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblPesoDetalle.setText("         ");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblDescripcion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblTipoDetalle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblPlumaje, javax.swing.GroupLayout.DEFAULT_SIZE, 52, Short.MAX_VALUE))
                        .addContainerGap(32, Short.MAX_VALUE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(btnCotejoManual))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblPava, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblPesoDetalle, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDescripcion)
                    .addComponent(jLabel7))
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTipoDetalle)
                            .addComponent(jLabel8))
                        .addGap(26, 26, 26))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblPlumaje)
                            .addComponent(jLabel9))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPava)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(lblPesoDetalle))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnCotejoManual)
                .addContainerGap())
        );

        lblGallosLibres.setText("Registros Encotrados:");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblGallosLibres)))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblGallosLibres))
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 6, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Gallos Libres", jPanel9);

        tablaPeleasPactadas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Cotejo", "Tipo", "Cuerda", "Anillo", "Gallo", "de Peso", "Marca", "Región", "Vs Tipo", "Cuerda", "Anillo", "Gallo", "de Peso", "Marca", "Región"
            }
        ));
        jScrollPane5.setViewportView(tablaPeleasPactadas);

        lblPeleasPactadas.setText("Número de peleas pactadas:");

        jPanel15.setBackground(new java.awt.Color(255, 153, 0));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Peleas Pactadas para la Contienda");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15)
                .addContainerGap(861, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPanel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 534, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblPeleasPactadas)
                            .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane5))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(13, 13, 13)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblPeleasPactadas)
                .addContainerGap())
        );

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jInternalFrame1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jInternalFrame1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tablaGallosLibresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaGallosLibresMouseClicked
        Gallo gallo = Inicializador.buscarObjetoGalloPorId(Integer.valueOf(tablaGallosLibres.getValueAt(tablaGallosLibres.getSelectedRow(), 0).toString()));
        lblCuerdaDetalle.setText(gallo.getCuerda().getNombre());
        lblDescripcion.setText(gallo.getRegion().getNombre());
        lblTipoDetalle.setText(gallo.getTipo().getNombre());
        lblPesoDetalle.setText(gallo.getPesoGramos().toString());
        lblPlumaje.setText(gallo.getPlumaje().getNombre());
        lblPava.setText(gallo.isPava() ? "Sí" : "No");
    }//GEN-LAST:event_tablaGallosLibresMouseClicked

    private void rBtnGallo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rBtnGallo1ActionPerformed
        System.out.println("sel " + rBtnGallo1.isSelected());
        if (rBtnGallo1.isSelected()) {
            if (tablaGallosLibres.getSelectedRow() >= 0) {
                String galloId = tablaGallosLibres.getValueAt(tablaGallosLibres.getSelectedRow(), 0).toString();
                rBtnGallo1.setText("Gallo " + galloId);
                idGalloManual1 = Integer.valueOf(galloId);
            } else {
                JOptionPane.showMessageDialog(null, "No hay registros seleccionados");
                rBtnGallo1.setSelected(false);
                rBtnGallo1.setText("Gallo");
                idGalloManual1 = null;
            }
        } else {
            rBtnGallo1.setText("Gallo");
            idGalloManual1 = null;
        }
    }//GEN-LAST:event_rBtnGallo1ActionPerformed

    private void rBtnGallo2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rBtnGallo2ActionPerformed
        if (rBtnGallo2.isSelected()) {
            if (tablaGallosLibres.getSelectedRow() >= 0) {
                Integer galloId = Integer.valueOf(tablaGallosLibres.getValueAt(tablaGallosLibres.getSelectedRow(), 0).toString());
                if (idGalloManual1 != null && idGalloManual1.equals(galloId)) {
                    rBtnGallo2.setSelected(false);
                    JOptionPane.showMessageDialog(null, "No puede pelear el mismo gallo", "Error", JOptionPane.ERROR_MESSAGE);
                } else {

                    if (idGalloManual1 == null) {
                        JOptionPane.showMessageDialog(null, "Debe selecionar el gallo inicial", "Error", JOptionPane.ERROR_MESSAGE);
                        rBtnGallo2.setSelected(false);
                    } else {
                        rBtnGallo2.setText("Gallo " + galloId);
                        idGalloManual2 = galloId;
                    }

                }
            } else {
                JOptionPane.showMessageDialog(null, "No hay registros seleccionados");
                rBtnGallo2.setSelected(false);
                rBtnGallo2.setText("Gallo");
                idGalloManual2 = null;
            }
        } else {
            rBtnGallo2.setText("Gallo");
            idGalloManual2 = null;
        }
    }//GEN-LAST:event_rBtnGallo2ActionPerformed

    private void btnCotejarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCotejarActionPerformed
        try {
            int tolerancia = Integer.valueOf(txtGramosTolerancia.getText());
            Map<Gallo, Gallo> mapSorteo = generarSorteo(tolerancia);
            if (mapSorteo.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No se encontrarón registros que coincidan");
            } else {
                Inicializador.insertPelea(mapSorteo, Tipo_Generacion.AUTOMATICA, tolerancia);
            }
            cargarCotejos();
            cargarTablaGallosLibres();
            limpiarTablas();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Tolerancia no valida [" + txtGramosTolerancia.getText() + "]", "Error de tolerancia", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnCotejarActionPerformed

    private void limpiarTablas() {
        String[] encabezado = {"TIPO", "ID", "ANILLO", "PLUMAJE", "PESO"};
        String[] encabezadoPeleas = {"Cotejo", "Tipo", "Cuerda", "Anillo", "De peso", "Marca", "Región",
            "Vs Tipo", "Cuerda", "Anillo", "Gallo", "De peso", "Marca", "Región"};
        String[][] data = new String[WIDTH][WIDTH];
        ModeloDatos modelo = new ModeloDatos(data, encabezado, false);
        ModeloDatos modelo2 = new ModeloDatos(data, encabezadoPeleas, false);
        tablaGallo1.setModel(modelo);
        tablaGallo2.setModel(modelo);
        tablaPeleasPactadas.setModel(modelo2);
        lblCuerda1.setText("");
        lblCuerda2.setText("");
        rBtnGallo1.setSelected(false);
        rBtnGallo2.setSelected(false);
        idGalloManual1 = null;
        idGalloManual2 = null;

    }

    private void tablaCotejosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaCotejosMouseClicked
        cargarTablaGalloVSGallo();
    }//GEN-LAST:event_tablaCotejosMouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (tablaCotejos.getSelectedRows().length > 0) {
            int accion = JOptionPane.showConfirmDialog(null, "Está seguro liberar las peleas pactadas?: ", "Liberar Todo", JOptionPane.PLAIN_MESSAGE);
            if (accion == 0) {
                for (int row : tablaCotejos.getSelectedRows()) {
                    Inicializador.borrarCotejoPorId(Integer.valueOf(tablaCotejos.getValueAt(row, 0).toString()));
                }
                cargarCotejos();
                cargarTablaGallosLibres();
                limpiarTablas();
            }

        } else {
            JOptionPane.showMessageDialog(null, "No hay registros seleccionados");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void tablaGallo1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tablaGallo1KeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tablaGallo1KeyReleased

    private void tablaGallo1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tablaGallo1KeyPressed

        // TODO add your handling code here:
    }//GEN-LAST:event_tablaGallo1KeyPressed

    private void tablaGallo1PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_tablaGallo1PropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_tablaGallo1PropertyChange

    private void tablaGallo1VetoableChange(java.beans.PropertyChangeEvent evt)throws java.beans.PropertyVetoException {//GEN-FIRST:event_tablaGallo1VetoableChange
        // TODO add your handling code here:
    }//GEN-LAST:event_tablaGallo1VetoableChange

    private void tablaGallo1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tablaGallo1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_tablaGallo1KeyTyped

    private void tablaCotejosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tablaCotejosKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_tablaCotejosKeyPressed

    private void tablaCotejosKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tablaCotejosKeyReleased
        cargarTablaGalloVSGallo();       // TODO add your handling code here:
    }//GEN-LAST:event_tablaCotejosKeyReleased

    private void btnCotejoManualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCotejoManualActionPerformed

        if (idGalloManual1 != null && idGalloManual2 != null) {
            Gallo gallo1 = Inicializador.buscarObjetoGalloPorId(idGalloManual1);
            Gallo gallo2 = Inicializador.buscarObjetoGalloPorId(idGalloManual2);
            StringBuilder infoGallo1 = new StringBuilder();
            infoGallo1.append("<h1>Enfrentar").append("</h1>");
//            infoGallo1.append("<br>");
            infoGallo1.append("<p>Gallo: <b>").append(gallo1.getIdGallo()).append("</b>");
            infoGallo1.append("<p>Cuerda: <b>").append(gallo1.getCuerda().getNombre()).append("</b>");
            infoGallo1.append("<p>Peso: <b>").append(gallo1.getPesoGramos()).append("</b>");;
            infoGallo1.append("<p>Tipo: <b>").append(gallo1.getTipo().getNombre()).append("</b>");;
            infoGallo1.append("<p>Región: <b>").append(gallo1.getRegion().getNombre()).append("</b>");
            infoGallo1.append("&nbsp;<h2>&nbsp; &nbsp; &nbsp; &nbsp; VS</h2>");
            infoGallo1.append("<p>Gallo: <b>").append(gallo2.getIdGallo()).append("</b>");
            infoGallo1.append("<p>Cuerda: <b>").append(gallo2.getCuerda().getNombre()).append("</b>");
            infoGallo1.append("<p>Peso: <b>").append(gallo2.getPesoGramos()).append("</b>");;
            infoGallo1.append("<p>Tipo: <b>").append(gallo2.getTipo().getNombre()).append("</b>");;
            infoGallo1.append("<p>Región: <b>").append(gallo2.getRegion().getNombre()).append("</b>");
            StringBuilder html = new StringBuilder();
            html.append("<html><body width='%1s'>");
            html.append(infoGallo1);
            int w = 175;
            int input = JOptionPane.showConfirmDialog(null, String.format(html.toString(), w, w));
            // 0=yes, 1=no, 2=cancel
            switch (input) {
                case 0:
                    int tolerancia = Integer.valueOf(txtGramosTolerancia.getText());
                    Inicializador.insertPeleaManual(gallo1, gallo2, Inicializador.consultarTorneoActivo().getId(), Tipo_Generacion.MANUAL, tolerancia);
                    cargarCotejos();
                    cargarTablaGallosLibres();
                    limpiarTablas();
                    break;
                case 1:
                    break;
                case 2:
                    break;
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay registros seleccionados");
        }
    }//GEN-LAST:event_btnCotejoManualActionPerformed

    private void btnPactarPeleasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPactarPeleasActionPerformed
        int gallosLibres = Inicializador.gallosLibres(Inicializador.consultarTorneoActivo().getId()).size();
        if (gallosLibres > 0) {
            JOptionPane.showMessageDialog(null, "Aún existen gallos libres", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int input = JOptionPane.showConfirmDialog(null, "¿Está seguro de pactar las peleas generadas?");
        if (input == 0) {
            Inicializador.pactarPeleas(EstadoPelea.PACTADA.getId());
            cargarCotejos();
            cargarTablaGallosLibres();
            limpiarTablas();
            cargarTablaPeleasPactadas();
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btnPactarPeleasActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        Utilidades.imprimirPeleas(Inicializador.consultarTodosCotejos());
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void cargarTablaGalloVSGallo() {

        String[] encabezado = {"TIPO", "ID", "ANILLO", "PLUMAJE", "PESO"};
        Gallo gallo1 = Inicializador.buscarObjetoGalloPorId(Integer.valueOf(tablaCotejos.getValueAt(tablaCotejos.getSelectedRow(), 1).toString()));
        Object informacion[][] = new Object[1][encabezado.length];
        informacion[0][0] = gallo1.getTipo().getNombre();
        informacion[0][1] = gallo1.getIdGallo().toString();
        informacion[0][2] = gallo1.getAnillo();
        informacion[0][3] = gallo1.getPlumaje().getNombre();
        informacion[0][4] = Utilidades.darFormatoVisualPeso(gallo1.getPesoGramos());
        lblCuerda1.setText(gallo1.getCuerda().getNombre());

        ModeloDatos modelo1 = new ModeloDatos(informacion, encabezado, false);
        tablaGallo1.setModel(modelo1);

        Gallo gallo2 = Inicializador.buscarObjetoGalloPorId(Integer.valueOf(tablaCotejos.getValueAt(tablaCotejos.getSelectedRow(), 2).toString()));
        informacion[0][0] = gallo2.getTipo().getNombre();
        informacion[0][1] = gallo2.getIdGallo().toString();
        informacion[0][2] = gallo2.getAnillo();
        informacion[0][3] = gallo2.getPlumaje().getNombre();
        informacion[0][4] = Utilidades.darFormatoVisualPeso(gallo2.getPesoGramos());
        lblCuerda2.setText(gallo2.getCuerda().getNombre());
        ModeloDatos modelo2 = new ModeloDatos(informacion, encabezado, false);
        tablaGallo2.setModel(modelo2);
    }

    private void cargarCotejos() {
        String[] encabezado = {"Cotejo", "Gallo", "VS Gallo", "Estado"};
        List<Cotejo> listCotejo = Inicializador.consultarCotejosPorTorneo(Inicializador.consultarTorneoActivo().getId());
        Object informacion[][] = new Object[listCotejo.size()][encabezado.length];
        for (int i = 0; i < listCotejo.size(); i++) {
            Cotejo cotejo = listCotejo.get(i);
            informacion[i][0] = cotejo.getId().toString();
            informacion[i][1] = cotejo.getGallo1().getIdGallo();
            informacion[i][2] = cotejo.getGallo2().getIdGallo();
            informacion[i][3] = cotejo.getEstado().getDescripcion();
        }
        ModeloDatos modelo = new ModeloDatos(informacion, encabezado, false);
        tablaCotejos.setModel(modelo);
        txtGallosCotejar.setText(String.valueOf(Inicializador.gallosLibres(Inicializador.consultarTorneoActivo().getId()).size()));
    }

    private Map<Gallo, Gallo> generarSorteo(int tolerancia) {
        List<Gallo> list = Inicializador.consultarGallosParaSorteo(Inicializador.consultarTorneoActivo().getId());
        Map<Gallo, Gallo> mapSorteo = new HashMap<>();
        for (int i = 0; i < list.size(); i++) {
            Gallo gallo1 = list.get(i);
            if (gallo1.isLibre()) {
                List<Gallo> listTemp = Utilidades.copiarLista(list, i + 1);
                if (listTemp.size() > 0) {
                    Gallo gallo2 = Utilidades.encontrarRival(listTemp, gallo1, tolerancia, mapExepcionesCuerdas, mapExepcionesRegiones);
                    if (gallo2 != null) {
                        for (Gallo gallo : list) {
                            if (gallo2.getIdGallo().equals(gallo.getIdGallo())) {
                                mapSorteo.put(gallo1, gallo2);
                                gallo.setLibre(false);
                            }
                            if (gallo1.getIdGallo().equals(gallo.getIdGallo())) {
                                gallo.setLibre(false);
                            }
                        }
                    }
                }
            }
        }
        return mapSorteo;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DialogCotejoGallos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DialogCotejoGallos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DialogCotejoGallos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DialogCotejoGallos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                DialogCotejoGallos dialog = new DialogCotejoGallos(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCotejar;
    private javax.swing.JButton btnCotejoManual;
    private javax.swing.JButton btnPactarPeleas;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lblCuerda1;
    private javax.swing.JLabel lblCuerda2;
    private javax.swing.JLabel lblCuerdaDetalle;
    private javax.swing.JLabel lblDescripcion;
    private javax.swing.JLabel lblGallosLibres;
    private javax.swing.JLabel lblPava;
    private javax.swing.JLabel lblPeleasEncontradas;
    private javax.swing.JLabel lblPeleasPactadas;
    private javax.swing.JLabel lblPesoDetalle;
    private javax.swing.JLabel lblPlumaje;
    private javax.swing.JLabel lblTipoDetalle;
    private javax.swing.JLabel lblTolerancia;
    private javax.swing.JRadioButton rBtnGallo1;
    private javax.swing.JRadioButton rBtnGallo2;
    private javax.swing.JTable tablaCotejos;
    private javax.swing.JTable tablaGallo1;
    private javax.swing.JTable tablaGallo2;
    private javax.swing.JTable tablaGallosLibres;
    private javax.swing.JTable tablaPeleasPactadas;
    private javax.swing.JTextField txtGallosCotejar;
    private javax.swing.JTextField txtGramosTolerancia;
    // End of variables declaration//GEN-END:variables
}
